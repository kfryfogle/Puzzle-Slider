'''
CS 5001
Fall 2021
Puzzle Project

Kyle Fryfogle
'''
import turtle
import PositionService
import random
import os.path
import time
from turtle_template import outline
from turtle_template import top_window
    
def meta_reader(filename):
    if not os.path.exists("5001_puzz.err"):
        open('5001_puzz.err', mode='w').close()
        
    with open('5001_puzz.err', mode='a') as errors:
        # yoshi filechecker
        if filename == "yoshi":
            with open("../final_project_fall_2021/" \
                      "slider_puzzle_project_fall2021_assets/" \
                      "yoshi.puz") as file:
                lines = file.readlines()
            for i in range(len(lines)):
                lines[i] = lines[i].replace('\n', '')
            if len(lines) != 8:
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Value Error: Not enough metadata info"  \
                             + '\n')
                raise ValueError
            if lines[0] != "name: yoshi":
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("incorrect name in yoshi metadata" + '\n')
                raise OSError
            # number line
            lines[1] = lines[1].replace('number: ', '')
            if int(lines[1]) != 4:
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Value Error: Incorrect Puzzle Size" + '\n')
                raise ValueError
            # size line
            lines[2] = lines[2].replace('size: ', '')
            if int(lines[2]) < 50 or int(lines[2]) > 110:
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Value Error: Incorrect Image Size" + '\n')
                raise ValueError
            # thumbnail line
            lines[3] = lines[3].replace('thumbnail: ', '')
            if lines[3] != "Images/yoshi/yoshi_thumbnail.gif":
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect file in yoshi thumbnail" + '\n')
                raise OSError
            # image 1 line
            lines[4] = lines[4].replace('1: ', '')
            if lines[4] != 'Images/yoshi/4.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in yoshi image position 1" \
                              + '\n')
                raise OSError
            # image 2 line
            lines[5] = lines[5].replace('2: ', '')
            if lines[5] != 'Images/yoshi/3.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in yoshi image position 2" \
                              + '\n')
                raise OSError
            # image 3 line
            lines[6] = lines[6].replace('3: ', '')
            if lines[6] != 'Images/yoshi/2.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in yoshi image position 3" \
                              + '\n')
                raise OSError
            # image 4 line
            lines[7] = lines[7].replace('4: ', '')
            if lines[7] != 'Images/yoshi/blank.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in yoshi image position 4" \
                              + '\n')
                raise OSError
            
        # luigi filechecker
        elif filename == "luigi":
            with open("../final_project_fall_2021/" \
                      "slider_puzzle_project_fall2021_assets/" \
                      "luigi.puz") as file:
                lines = file.readlines()
            for i in range(len(lines)):
                lines[i] = lines[i].replace('\n', '')
            if len(lines) != 13:
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Value Error: Not enough metadata info" \
                              + '\n')
                raise ValueError
            if lines[0] != "name: luigi":
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("incorrect name in yoshi metadata" \
                              + '\n')
                raise OSError
            # number line
            lines[1] = lines[1].replace('number: ', '')
            if int(lines[1]) != 9:
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Value Error: Incorrect Puzzle Size" \
                              + '\n')
                raise ValueError
            # size line
            lines[2] = lines[2].replace('size: ', '')
            if int(lines[2]) < 50 or int(lines[2]) > 110:
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Value Error: Incorrect Image Size" \
                              + '\n')
                raise ValueError
            # thumbnail line
            lines[3] = lines[3].replace('thumbnail: ', '')
            if lines[3] != "Images/luigi/luigi_thumbnail.gif":
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect file in luigi thumbnail" \
                              + '\n')
                raise OSError
            # image 1 line
            lines[4] = lines[4].replace('1: ', '')
            if lines[4] != 'Images/luigi/9.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in luigi image position 1" \
                              + '\n')
                raise OSError
            # image 2 line
            lines[5] = lines[5].replace('2: ', '')
            if lines[5] != 'Images/luigi/8.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in luigi image position 2" \
                              + '\n')
                raise OSError
            # image 3 line
            lines[6] = lines[6].replace('3: ', '')
            if lines[6] != 'Images/luigi/7.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in luigi image position 3" \
                              + '\n')
                raise OSError
            # image 4 line
            lines[7] = lines[7].replace('4: ', '')
            if lines[7] != 'Images/luigi/6.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in luigi image position 4" \
                              + '\n')
                raise OSError
            # image 5 line
            lines[8] = lines[8].replace('5: ', '')
            if lines[8] != 'Images/luigi/5.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in luigi image position 5" \
                              + '\n')
                raise OSError
            # image 6 line
            lines[9] = lines[9].replace('6: ', '')
            if lines[9] != 'Images/luigi/4.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in luigi image position 6" \
                              + '\n')
                raise OSError
            # image 7 line
            lines[10] = lines[10].replace('7: ', '')
            if lines[10] != 'Images/luigi/3.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in luigi image position 7" \
                              + '\n')
                raise OSError
            # image 8 line
            lines[11] = lines[11].replace('8: ', '')
            if lines[11] != 'Images/luigi/2.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in luigi image position 8" \
                              + '\n')
                raise OSError
            # image 9 line
            lines[12] = lines[12].replace('9: ', '')
            if lines[12] != 'Images/luigi/blank.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in luigi image position 9" \
                              + '\n')
                raise OSError

        # 16 x 16 filechecker
        elif filename == "mario" or filename == 'smiley' or \
           filename == 'fifteen':
            with open("../final_project_fall_2021/" \
                      "slider_puzzle_project_fall2021_assets/" \
                      f"{filename}.puz") as file:
                lines = file.readlines()
            for i in range(len(lines)):
                lines[i] = lines[i].replace('\n', '')
            if len(lines) != 20:
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Value Error: Not enough metadata info" \
                              + '\n')
                raise ValueError
            if lines[0] != f"name: {filename}":
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("incorrect name in yoshi metadata" \
                              + '\n')
                raise OSError
            # number line
            lines[1] = lines[1].replace('number: ', '')
            if int(lines[1]) != 16:
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Value Error: Incorrect Puzzle Size" \
                              + '\n')
                raise ValueError
            # size line
            lines[2] = lines[2].replace('size: ', '')
            if int(lines[2]) < 50 or int(lines[2]) > 110:
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Value Error: Incorrect Image Size" \
                              + '\n')
                raise ValueError
            # thumbnail line
            lines[3] = lines[3].replace('thumbnail: ', '')
            if lines[3] != f"Images/{filename}/{filename}_thumbnail.gif":
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect file in {filename} thumbnail" \
                              + '\n')
                raise OSError
            # image 1 line
            lines[4] = lines[4].replace('1: ', '')
            if lines[4] != f'Images/{filename}/16.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 1" + '\n')
                raise OSError
            # image 2 line
            lines[5] = lines[5].replace('2: ', '')
            if lines[5] != f'Images/{filename}/15.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 2" + '\n')
                raise OSError
            # image 3 line
            lines[6] = lines[6].replace('3: ', '')
            if lines[6] != f'Images/{filename}/14.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 3" + '\n')
                raise OSError
            # image 4 line
            lines[7] = lines[7].replace('4: ', '')
            if lines[7] != f'Images/{filename}/13.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 4" + '\n')
                raise OSError
            # image 5 line
            lines[8] = lines[8].replace('5: ', '')
            if lines[8] != f'Images/{filename}/12.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 5" + '\n')
                raise OSError
            # image 6 line
            lines[9] = lines[9].replace('6: ', '')
            if lines[9] != f'Images/{filename}/11.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 6" + '\n')
                raise OSError
            # image 7 line
            lines[10] = lines[10].replace('7: ', '')
            if lines[10] != f'Images/{filename}/10.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 7" + '\n')
                raise OSError
            # image 8 line
            lines[11] = lines[11].replace('8: ', '')
            if lines[11] != f'Images/{filename}/9.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 8" + '\n')
                raise OSError
            # image 9 line
            lines[12] = lines[12].replace('9: ', '')
            if lines[12] != f'Images/{filename}/8.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             "position 9" + '\n')
                raise OSError
            # image 10 line
            lines[13] = lines[13].replace('10: ', '')
            if lines[13] != f'Images/{filename}/7.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 10" + '\n')
                raise OSError
            # image 11 line
            lines[14] = lines[14].replace('11: ', '')
            if lines[14] != f'Images/{filename}/6.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 11" + '\n')
                raise OSError
            # image 12 line
            lines[15] = lines[15].replace('12: ', '')
            if lines[15] != f'Images/{filename}/5.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             "position 12" + '\n')
                raise OSError
            # image 13 line
            lines[16] = lines[16].replace('13: ', '')
            if lines[16] != f'Images/{filename}/4.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 13" + '\n')
                raise OSError
            # image 14 line
            lines[17] = lines[17].replace('14: ', '')
            if lines[17] != f'Images/{filename}/3.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 14" + '\n')
                raise OSError
            # image 15 line
            lines[18] = lines[18].replace('15: ', '')
            if lines[18] != f'Images/{filename}/2.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 15" + '\n')
                raise OSError
            # image 16 line
            lines[19] = lines[19].replace('16: ', '')
            if lines[19] != f'Images/{filename}/blank.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 16" + '\n')
                raise OSError

def visibility_check():
        with open("visibility.txt") as visible:
                check = visible.readline()
        if check == "visible":
                return True
        elif check == 'invisible':
                return False
            
def random_locations(game_name):
    if game_name.lower() == "yoshi":
        locations = [[-3, -72], [-101, -72], [-3, 26], [-101, 26]]
        rand_places = locations
        random.shuffle(rand_places)
        if rand_places == locations:
            random.shuffle(rand_places)
        return rand_places
    
    elif game_name.lower() == "luigi":
        locations = [[-3, -72], [-101, -72], [-199, -72], [-3, 26], \
                     [-101, 26], [-199, 26], [-3, 124], [-101, 124], \
                     [-199, 124]]
        rand_places = locations
        random.shuffle(rand_places)
        if rand_places == locations:
            random.shuffle(rand_places)
        return rand_places
    
    elif game_name.lower() == "mario" or game_name.lower() == "smiley" or \
         game_name.lower() == 'fifteen':
        locations = [[-3, -72], [-101, -72], [-199, -72], [-297, -72], \
                 [-3, 26], [-101, 26], [-199, 26], [-297, 26], [-3, 124], \
                 [-101, 124], [-199, 124], [-297, 124], [-3, 222], \
                 [-101, 222], [-199, 222], [-297, 222]]
        rand_places = locations
        random.shuffle(rand_places)
        if rand_places == locations:
            random.shuffle(rand_places)
        return rand_places
    
def game_picker(new_puzzle, username, moves):
    if new_puzzle == "yoshi":
        yoshi_game(username, moves)
    elif new_puzzle == "mario":
        mario_game(username, moves)
    elif new_puzzle == "smiley":
        smiley_game(username, moves)
    elif new_puzzle == "luigi":
        luigi_game(username, moves)
    elif new_puzzle == "fifteen":
        fifteen_game(username, moves)
        
def puzzle_validation(name):
        if name == "mario" or name == "luigi" or name == "yoshi" \
           or name == "smiley" or name == "fifteen":
                return
        elif name != "mario" or name != "luigi" or name != "yoshi" \
           or name != "smiley" or name != "fifteen":
                with open('5001_puzz.err', mode='a') as errors:
                        errors.write(f"{time.localtime()}" + "\n")
                        errors.write('incorrect puzzle input' + '\n')
                raise FileNotFoundError
        


def yoshi_game(username, moves):
    def click_yoshi(x, y):
        vision = visibility_check()
        turtles = [blank, tile_2, tile_3, tile_4]
        blank_x = PositionService.get_position_x()
        blank_y = PositionService.get_position_y()
        quit_x = 255
        quit_y = -250
        load_x = 142.5
        load_y = -249.5
        reset_x = 50
        reset_y = -250
        if vision == True:
                if x <= 400 and x >= -400 and y <= 400 and y >= -400:
                        popup.hideturtle()
                        with open("visibility.txt", mode='w') as vision:
                                vision.write('invisible')
        else:
                # Quit button
                if x >= (quit_x - 60) and x <= (quit_x + 60) \
                   and y >= (quit_y - 25) and y <= (quit_y + 25):
                    with open("visibility.txt", mode='w') as vision:
                            vision.write("visible")
                    popup.shape("../final_project_fall_2021/" \
                                "slider_puzzle_project_fall2021_assets/" \
                                "Resources/quitmsg.gif")
                    popup.showturtle()
                    time.sleep(5)
                    turtle.bye()
                # Load button
                elif x >= (load_x - 37.5) and x <= (load_x + 37.5) \
                   and y >= (load_y - 37.5) and y <= (load_y + 37.5):
                    with open("visibility.txt", mode='w') as vision:
                            vision.write("invisible")
                    with open("game_status.txt", mode='w') as status:
                        status.write("ongoing")
                    new_puzzle = ts.textinput("5001 Puzzle Slide - Load", \
                                              "Which puzzle would you" \
                                              " like to switch" \
                                              " to?\nOptions:\nMario\n" \
                                              "Luigi\nYoshi\nSmiley\n" \
                                              "Fifteen")
                    new_puzzle = new_puzzle.lower()
                    puzzle_validation(new_puzzle)
                    # Hide all relevant turtles, clear board
                    for each in turtles:
                        each.hideturtle()
                    turts.hideturtle()
                    # Choose new game, location and controls
                    game_picker(new_puzzle, username, moves)
                    with open("scorekeeper.txt", mode='w') as new_score:
                        current_score = [f'{username}', '0', f'{moves}']
                        current_score = ":".join(current_score)
                        new_score.write(current_score)
                    score_presenter()
                # Reset button
                elif x >= (reset_x - 40) and x <= (reset_x + 40) \
                   and y >= (reset_y - 40) and y <= (reset_y + 40): 
                    with open("game_status.txt", mode='w') as status:
                            status.write("completed")
                    locations = [[-3, -72], [-101, -72], [-3, 26], [-101, 26]]
                    blank.setpos(locations[0][0], locations[0][1])
                    PositionService.set_position(locations[0][0], \
                                                 locations[0][1])
                    tile_2.setpos(locations[1][0], locations[1][1])
                    tile_3.setpos(locations[2][0], locations[2][1])
                    tile_4.setpos(locations[3][0], locations[3][1])
                    score_check()
                # Bottom Right White Tile
                elif blank_x == -3 and blank_y == -72:
                    # Go Bot Left
                    if x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-101, -72):
                                each.setpos(-3, -72)
                                blank.setpos(-101, -72)
                                PositionService.set_position(-101, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Right
                    elif x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 26):
                                each.setpos(-3, -72)
                                blank.setpos(-3, 26)
                                PositionService.set_position(-3, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Bot Left White Tile
                elif blank_x == -101 and blank_y == -72:
                    # Go Bot Right
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-3, -72):
                                each.setpos(-101, -72)
                                blank.setpos(-3, -72)
                                PositionService.set_position(-3, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Left
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 26):
                                each.setpos(-101, -72)
                                blank.setpos(-101, 26)
                                PositionService.set_position(-101, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Top Right White Tile
                elif blank_x == -3 and blank_y == 26:
                    # Go Bot Right
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-3, -72):
                                each.setpos(-3, 26)
                                blank.setpos(-3, -72)
                                PositionService.set_position(-3, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Left
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 26):
                                each.setpos(-3, 26)
                                blank.setpos(-101, 26)
                                PositionService.set_position(-101, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Top Left White Tile
                elif blank_x == -101 and blank_y == 26:
                    # Go Top Right
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 26):
                                each.setpos(-101, 26)
                                blank.setpos(-3, 26)
                                PositionService.set_position(-3, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Bot Left
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-101, -72):
                                each.setpos(-101, 26)
                                blank.setpos(-101, -72)
                                PositionService.set_position(-101, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()

    def thumbnail(image: str):
        screen = turtle.getscreen()
        turts.penup()
        turts.hideturtle()
        turts.setposition(290, 260)
        pic = "../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              f"{image}/{image}_thumbnail.gif"
        screen.addshape(pic)
        turts.shape(pic)
        turts.showturtle()
        
    def score_presenter():
        score_present.speed(0)
        score_present.hideturtle()
        score_present.penup()
        score_present.setpos(-188, -267)
        score_present.fillcolor('beige')
        score_present.begin_fill()
        score_present.forward(100)
        score_present.left(90)
        score_present.forward(50)
        score_present.left(90)
        score_present.forward(103)
        score_present.left(90)
        score_present.forward(50)
        score_present.left(90)
        score_present.forward(3)
        score_present.end_fill()
        score_present.pencolor("#350A0A")
        style = ('Calibri', 26, 'bold')
        with open("scorekeeper.txt", mode='r') as score:
            scorer = score.readline()
            scores = scorer.split(":")
            score_present.write(f"{scores[1]}", font=style, align='left')
            
    def leaderboard_update(game_name):
        style = ('Calibri', 24, 'bold')
        with open(f"{game_name}_leaders.txt", mode='r') as leaderboard:
                board = leaderboard.readlines()
                for i in range(len(board)):
                        board[i] = board[i].replace("\n", "")
                        board[i] = board[i].split(':')
        leaders.pencolor("#350A0A")
        leaders.speed(0)
        leaders.penup()
        leaders.hideturtle()
        leaders.setpos(110, 210)
        leaders.fillcolor("beige")
        leaders.begin_fill()
        leaders.setheading(270)
        leaders.forward(300)
        leaders.left(90)
        leaders.forward(150)
        leaders.left(90)
        leaders.forward(300)
        leaders.left(90)
        leaders.forward(150)
        leaders.left(90)
        leaders.end_fill()
        leaders.setpos(110, 160)
        for i in range(len(board)):
                score = f"{board[i][1]}: {board[i][0]}"
                leaders.write(score, font=style, align='left')
                leaders.forward(60)
                
    def score_check():
        locations = [[-3, -72], [-101, -72], [-3, 26], [-101, 26]]
        turtles = [blank, tile_2, tile_3, tile_4]
        turtle_tracker = []
        for each in turtles:
            turtle_tracker.append(list(each.pos()))
        with open("scorekeeper.txt", mode="r") as scoreboard:
            current_score = scoreboard.readline()
            score = current_score.split(":")
            score[1] = int(score[1])
            score[2] = int(score[2])
            # If the score is less or equal to limit and locations
            # match solved
        if score[1] <= score[2] and turtle_tracker == locations:
            with open("game_status.txt") as status:
                    check = status.readline()
            if check == "ongoing":
                # making the current score a variable
                with open("scorekeeper.txt", mode='r') as \
                     scoreboard:
                        current_score = scoreboard.readline()
                        current_score = current_score.split(":")
                board = []
                # adds all logged scores to board list
                with open("yoshi_leaders.txt", mode='r') \
                     as leaderboard:
                        board = leaderboard.readlines()
                for i in range(len(board)):
                        board[i] = board[i].replace("\n", "")
                if len(board) == 0:
                        with open("yoshi_leaders.txt", mode='w') \
                                as empty_board:
                                current_score = ':'.join(current_score)
                                empty_board.write(current_score)                   
                elif len(board) < 5:
                        for i in range(len(board)):
                                board[i] = board[i].split(":")
                        # find index where current score is
                        # less than a leader
                        for i in range(len(board)):
                                # skip if score is greater
                                if int(current_score[1]) > int(board[i][1]):
                                        continue
                        # append index, break loop if score <= current line
                                elif int(current_score[1]) <= \
                                     int(board[i][1]):
                                        index_holder = i
                                        break
                        # failsafe if current score > all available
                        if int(current_score[1]) > int(board[-1][1]):
                                board.append(current_score)
                        elif index_holder >= 0:
                                board.insert(index_holder, current_score)
                        else:
                                pass
                        # need to write new scores back to file
                        with open("yoshi_leaders.txt", mode='w') as \
                             new_leads:
                                # del new line characters from last document
                                for each in board:
                                        each = ':'.join(each)
                                # reapply new line character for all
                                # but last index
                                for i in range(len(board)):
                                        if board[i] == board[-1]:
                                                board[i] = \
                                                         ':'.join(board[i])
                                                pass
                                        else:
                                                board[i][2] = board[i][2] \
                                                              + '\n'
                                                board[i] = \
                                                         ':'.join(board[i])
                                for each in board:
                                        new_leads.write(each)
                        leaderboard_update("yoshi")
                elif len(board) == 5:
                        for i in range(len(board)):
                                board[i] = board[i].split(":")
                        # find index where current score is less than leader
                        for i in range(len(board)):
                                # skip if score is greater
                                if int(current_score[1]) > int(board[i][1]):
                                        continue
                                # append index, break loop if
                                # score <= current line
                                elif int(current_score[1]) <= \
                                     int(board[i][1]):
                                        index_holder = i
                                        break
                        # failsafe if current score > all available
                        if int(current_score[1]) > int(board[-1][1]):
                                board.append(current_score)
                        elif index_holder >= 0:
                                board.insert(index_holder, current_score)
                        else:
                                pass
                        # del last value before reformatting
                        board.pop()
                        # need to write new scores back to file
                        with open("yoshi_leaders.txt", mode='w') as \
                             new_leads:
                                # del new line characters from last document
                                for each in board:
                                        each = ':'.join(each)
                                # reapply new line character for all
                                # but last index
                                for i in range(len(board)):
                                        if board[i] == board[-1]:
                                                board[i] = \
                                                         ':'.join(board[i])
                                                pass
                                        else:
                                                board[i][2] = \
                                                            board[i][2] + \
                                                            '\n'
                                                board[i] = \
                                                         ':'.join(board[i])
                                for each in board:
                                        new_leads.write(each)
                with open("game_status.txt", mode='w') as status:
                        status.write("completed")
                leaderboard_update("yoshi")
                with open("visibility.txt", mode='w') as vision:
                        vision.write("visible")
                popup.shape("../final_project_fall_2021/" \
                            "slider_puzzle_project_fall2021_assets/" \
                            "Resources/winner.gif")
                popup.showturtle()
                if check == "completed":
                        pass
        elif score[1] >= score[2] and turtle_tracker != locations:
                with open("visibility.txt", mode='w') as vision:
                        vision.write("visible")
                popup.shape("../final_project_fall_2021/" \
                            "slider_puzzle_project_fall2021_assets/" \
                            "Resources/Lose.gif")
                popup.showturtle()
        
    meta_reader('yoshi')
    ts = turtle.Screen()
    turts = turtle.Turtle()
    scorekeep = turtle.Turtle()
    score_present = turtle.Turtle()
    leaders = turtle.Turtle()
    splash = turtle.Turtle()
    popup = turtle.Turtle()
    blank = turtle.Turtle()
    tile_2 = turtle.Turtle()
    tile_3 = turtle.Turtle()
    tile_4 = turtle.Turtle()
    blank.hideturtle()
    tile_2.hideturtle()
    tile_3.hideturtle()
    tile_4.hideturtle()
    thumbnail("yoshi")
    score_presenter()
    randomizer = random_locations("yoshi")
    ts.addshape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "winner.gif")
    ts.addshape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "Lose.gif")
    ts.addshape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "quitmsg.gif")
    ts.addshape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "file_error.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              f"yoshi/blank.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              f"yoshi/2.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              f"yoshi/3.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              f"yoshi/4.gif")
    blank.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "yoshi/blank.gif")
    blank.penup()
    blank.setpos(randomizer[0][0], randomizer[0][1])
    tile_2.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              f"yoshi/2.gif")
    tile_2.penup()
    tile_2.setpos(randomizer[1][0], randomizer[1][1])
    tile_3.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              f"yoshi/3.gif")
    tile_3.penup()
    tile_3.setpos(randomizer[2][0], randomizer[2][1])
    tile_4.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              f"yoshi/4.gif")
    tile_4.penup()
    tile_4.setpos(randomizer[3][0], randomizer[3][1])
    PositionService.set_position(blank.xcor(), blank.ycor())
    time.sleep(4)
    blank.showturtle()
    tile_2.showturtle()
    tile_3.showturtle()
    tile_4.showturtle()
    #if file missing, write blank version
    if not os.path.exists('yoshi_leaders.txt'):
        open('yoshi_leaders.txt', mode='w').close()
    with open("game_status.txt", mode='w') as status:
            status.write("ongoing")
    if not os.path.exists("visibility.txt"):
            vision = open('visibility.txt', mode='w')
    popup.hideturtle()
    with open("visibility.txt", mode='w') as vision:
            vision.write('invisible')
    leaderboard_update("yoshi")
    ts.onclick(click_yoshi)

def luigi_game(username, moves):
    def click_luigi(x, y):
        turtles = [blank, tile_2, tile_3, tile_4, tile_5, tile_6, tile_7, \
                   tile_8, tile_9]
        vision = visibility_check()
        blank_x = PositionService.get_position_x()
        blank_y = PositionService.get_position_y()
        quit_x = 255
        quit_y = -250
        load_x = 142.5
        load_y = -249.5
        reset_x = 50
        reset_y = -250
        if vision == True:
                if x <= 400 and x >= -400 and y <= 400 and y >= -400:
                        popup.hideturtle()
                        with open("visibility.txt", mode='w') as vision:
                                vision.write('invisible')
        else:
                # Quit button
                if x >= (quit_x - 60) and x <= (quit_x + 60) \
                   and y >= (quit_y - 25) and y <= (quit_y + 25):
                    with open("visibility.txt", mode='w') as vision:
                            vision.write("visible")
                    popup.shape("../final_project_fall_2021/" \
                                "slider_puzzle_project_fall2021_assets/" \
                                "Resources/quitmsg.gif")
                    popup.showturtle()
                    time.sleep(5)
                    turtle.bye()
                # Load button
                elif x >= (load_x - 37.5) and x <= (load_x + 37.5) \
                   and y >= (load_y - 37.5) and y <= (load_y + 37.5): 
                    with open("visibility.txt", mode='w') as vision:
                            vision.write("invisible")
                    with open("game_status.txt", mode='w') as status:
                        status.write("ongoing")
                    new_puzzle = ts.textinput("5001 Puzzle Slide - Load", \
                                              "Which puzzle would you" \
                                              " like to switch" \
                                              " to?\nOptions:\nMario\n" \
                                              "Luigi\nYoshi\nSmiley\n" \
                                              "Fifteen")
                    new_puzzle = new_puzzle.lower()
                    puzzle_validation(new_puzzle)
                    turts.hideturtle()
                    # Hide all relevant turtles, clear board
                    for each in turtles:
                        each.hideturtle()
                    # Choose new game, location and controls
                    game_picker(new_puzzle, username, moves)
                    with open("scorekeeper.txt", mode='w') as new_score:
                        current_score = [f'{username}', '0', f'{moves}']
                        current_score = ":".join(current_score)
                        new_score.write(current_score)
                    score_presenter()
                # Reset button
                elif x >= (reset_x - 40) and x <= (reset_x + 40) \
                   and y >= (reset_y - 40) and y <= (reset_y + 40):
                    with open("game_status.txt", mode='w') as status:
                            status.write("completed")
                    locations = [[-3, -72], [-101, -72], [-199, -72], \
                                 [-3, 26], [-101, 26], [-199, 26], \
                                 [-3, 124], [-101, 124], [-199, 124]]
                    score = 0
                    blank.setpos(locations[0][0], locations[0][1])
                    PositionService.set_position(locations[0][0], \
                                                 locations[0][1])
                    tile_2.setpos(locations[1][0], locations[1][1])
                    tile_3.setpos(locations[2][0], locations[2][1])
                    tile_4.setpos(locations[3][0], locations[3][1])
                    tile_5.setpos(locations[4][0], locations[4][1])
                    tile_6.setpos(locations[5][0], locations[5][1])
                    tile_7.setpos(locations[6][0], locations[6][1])
                    tile_8.setpos(locations[7][0], locations[7][1])
                    tile_9.setpos(locations[8][0], locations[8][1])
                    score_check()
                # Bottom Right White Tile
                elif blank_x == -3 and blank_y == -72:
                    # Go Bot Left
                    if x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-101, -72):
                                each.setpos(-3, -72)
                                blank.setpos(-101, -72)
                                PositionService.set_position(-101, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Right
                    elif x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 26):
                                each.setpos(-3, -72)
                                blank.setpos(-3, 26)
                                PositionService.set_position(-3, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Middle Bottom White Tile
                elif blank_x == -101 and blank_y == -72:
                    # Go Bot Right 1/3
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-3, -72):
                                each.setpos(-101, -72)
                                blank.setpos(-3, -72)
                                PositionService.set_position(-3, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Middle 2/3
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 26):
                                each.setpos(-101, -72)
                                blank.setpos(-101, 26)
                                PositionService.set_position(-101, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Bot Left 3/3
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48): 
                        for each in turtles:
                            if each.pos() == (-199, -72):
                                each.setpos(-101, -72)
                                blank.setpos(-199, -72)
                                PositionService.set_position(-199, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Bot Left White Tile
                elif blank_x == -199 and blank_y == -72:
                    # Go Bot Mid
                    if x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-101, -72):
                                each.setpos(-199, -72)
                                blank.setpos(-101, -72)
                                PositionService.set_position(-101, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Mid Left
                    elif x <= (-199 + 48) and x >= (-199 -48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 26):
                                each.setpos(-199, -72)
                                blank.setpos(-199, 26)
                                PositionService.set_position(-199, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Middle Right White Tile
                elif blank_x == -3 and blank_y == 26:
                    # Go Bot Right 1/3
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-3, -72):
                                each.setpos(-3, 26)
                                blank.setpos(-3, -72)
                                PositionService.set_position(-3, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Middle 2/3
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 26):
                                each.setpos(-3, 26)
                                blank.setpos(-101, 26)
                                PositionService.set_position(-101, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Right 3/3
                    elif x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 124):
                                each.setpos(-3, 26)
                                blank.setpos(-3, 124)
                                PositionService.set_position(-3, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                            print(current_score)
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Center White Tile
                elif blank_x == -101 and blank_y == 26:
                    # Go Mid Right 1/4
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 26):
                                each.setpos(-101, 26)
                                blank.setpos(-3, 26)
                                PositionService.set_position(-3, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Bot Mid 2/4
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-101, -72): 
                                each.setpos(-101, 26)
                                blank.setpos(-101, -72)
                                PositionService.set_position(-101, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Mid Left 3/4
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 26): 
                                each.setpos(-101, 26)
                                blank.setpos(-199, 26)
                                PositionService.set_position(-199, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Mid 4/4
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 124): 
                                each.setpos(-101, 26)
                                blank.setpos(-101, 124)
                                PositionService.set_position(-101, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Middle Left White Tile
                elif blank_x == -199 and blank_y == 26:
                    # Go Bot Left 1/3
                    if x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-199, -72):
                                each.setpos(-199, 26)
                                blank.setpos(-199, -72)
                                PositionService.set_position(-199, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Middle 2/3
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48): 
                        for each in turtles:
                            if each.pos() == (-101, 26):
                                each.setpos(-199, 26)
                                blank.setpos(-101, 26)
                                PositionService.set_position(-101, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Left 3/3
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 124):
                                each.setpos(-199, 26)
                                blank.setpos(-199, 124)
                                PositionService.set_position(-199, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Top Right White Tile
                elif blank_x == -3 and blank_y == 124:
                    # Go Mid Right 1/2
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 26):
                                each.setpos(-3, 124)
                                blank.setpos(-3, 26)
                                PositionService.set_position(-3, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Middle 2/2
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 124):
                                each.setpos(-3, 124)
                                blank.setpos(-101, 124)
                                PositionService.set_position(-101, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Middle Top White Tile
                elif blank_x == -101 and blank_y == 124:
                    # Go Top Right 1/3
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 124):
                                each.setpos(-101, 124)
                                blank.setpos(-3, 124)
                                PositionService.set_position(-3, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Middle 2/3
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 26):
                                each.setpos(-101, 124)
                                blank.setpos(-101, 26)
                                PositionService.set_position(-101, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Left 3/3
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 124):
                                each.setpos(-101, 124)
                                blank.setpos(-199, 124)
                                PositionService.set_position(-199, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Top left White Tile
                elif blank_x == -199 and blank_y == 124:
                    # Go Mid Left 1/2
                    if x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 26):
                                each.setpos(-199, 124)
                                blank.setpos(-199, 26)
                                PositionService.set_position(-199, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Middle 2/2
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 124):
                                each.setpos(-199, 124)
                                blank.setpos(-101, 124)
                                PositionService.set_position(-101, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                        
    def thumbnail(image: str):
        screen = turtle.getscreen()
        turts.penup()
        turts.hideturtle()
        turts.setposition(290, 260)
        pic = "../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              f"{image}/{image}_thumbnail.gif"
        screen.addshape(pic)
        turts.shape(pic)
        turts.showturtle()
                
    def leaderboard_update(game_name):
        style = ('Calibri', 24, 'bold')
        with open(f"{game_name}_leaders.txt", mode='r') as leaderboard:
                board = leaderboard.readlines()
                for i in range(len(board)):
                        board[i] = board[i].replace("\n", "")
                        board[i] = board[i].split(':')
        leaders.pencolor("#350A0A")
        leaders.speed(0)
        leaders.penup()
        leaders.hideturtle()
        leaders.setpos(110, 210)
        leaders.fillcolor("beige")
        leaders.begin_fill()
        leaders.setheading(270)
        leaders.forward(300)
        leaders.left(90)
        leaders.forward(150)
        leaders.left(90)
        leaders.forward(300)
        leaders.left(90)
        leaders.forward(150)
        leaders.left(90)
        leaders.end_fill()
        leaders.setpos(110, 160)
        for i in range(len(board)):
                score = f"{board[i][1]}: {board[i][0]}"
                leaders.write(score, font=style, align='left')
                leaders.forward(60)
                
    def score_presenter():
        score_present.speed(0)
        score_present.hideturtle()
        score_present.penup()
        score_present.setpos(-188, -267)
        score_present.fillcolor('beige')
        score_present.begin_fill()
        score_present.forward(100)
        score_present.left(90)
        score_present.forward(50)
        score_present.left(90)
        score_present.forward(103)
        score_present.left(90)
        score_present.forward(50)
        score_present.left(90)
        score_present.forward(3)
        score_present.end_fill()
        score_present.pencolor("#350A0A")
        style = ('Calibri', 26, 'bold')
        with open("scorekeeper.txt", mode='r') as score:
            scorer = score.readline()
            scores = scorer.split(":")
            score_present.write(f"{scores[1]}", font=style, align='left')
            
    def score_check():
        locations = [[-3, -72], [-101, -72], [-199, -72], [-3, 26], \
                     [-101, 26], [-199, 26], [-3, 124], [-101, 124], \
                     [-199, 124]]
        turtles = [blank, tile_2, tile_3, tile_4, tile_5, tile_6, tile_7, \
                   tile_8, tile_9]
        turtle_tracker = []
        for each in turtles:
            turtle_tracker.append(list(each.pos()))
        with open("scorekeeper.txt", mode="r") as scoreboard:
            current_score = scoreboard.readline()
            score = current_score.split(":")
            score[1] = int(score[1])
            score[2] = int(score[2])
            # If the score is less or equal to limit and locations
            # match solved
        if score[1] <= score[2] and turtle_tracker == locations:
            with open("game_status.txt") as status:
                    check = status.readline()
            if check == "ongoing":
                # making the current score a variable
                with open("scorekeeper.txt", mode='r') as \
                     scoreboard:
                        current_score = scoreboard.readline()
                        current_score = current_score.split(":")
                board = []
                # adds all logged scores to board list
                with open("luigi_leaders.txt", mode='r') \
                     as leaderboard:
                        board = leaderboard.readlines()
                for i in range(len(board)):
                        board[i] = board[i].replace("\n", "")
                if len(board) == 0:
                        with open("luigi_leaders.txt", mode='w') \
                                as empty_board:
                                current_score = ':'.join(current_score)
                                empty_board.write(current_score)
                                        
                elif len(board) < 5:
                        for i in range(len(board)):
                                board[i] = board[i].split(":")
                        # find index where current score is
                        # less than a leader
                        for i in range(len(board)):
                                # skip if score is greater
                                if int(current_score[1]) > int(board[i][1]):
                                        continue
                        # append index, break loop if score <= current line
                                elif int(current_score[1]) <= \
                                     int(board[i][1]):
                                        index_holder = i
                                        break
                        # failsafe if current score > all available
                        if int(current_score[1]) > int(board[-1][1]):
                                board.append(current_score)
                        elif index_holder >= 0:
                                board.insert(index_holder, current_score)
                        else:
                                pass
                        # need to write new scores back to file
                        with open("luigi_leaders.txt", mode='w') as \
                             new_leads:
                                # del new line characters from last document
                                for each in board:
                                        each = ':'.join(each)
                                # reapply new line character for all
                                # but last index
                                for i in range(len(board)):
                                        if board[i] == board[-1]:
                                                board[i] = ':'.join(board[i])
                                                pass
                                        else:
                                                board[i][2] = board[i][2] \
                                                              + '\n'
                                                board[i] = \
                                                         ':'.join(board[i])
                                for each in board:
                                        new_leads.write(each)
                        leaderboard_update("luigi")
                elif len(board) == 5:
                        for i in range(len(board)):
                                board[i] = board[i].split(":")
                        # find index where current score is less than leader
                        for i in range(len(board)):
                                # skip if score is greater
                                if int(current_score[1]) > int(board[i][1]):
                                        continue
                                # append index, break loop if
                                # score <= current line
                                elif int(current_score[1]) <= \
                                     int(board[i][1]):
                                        index_holder = i
                                        break
                        # failsafe if current score > all available
                        if int(current_score[1]) > int(board[-1][1]):
                                board.append(current_score)
                        elif index_holder >= 0:
                                board.insert(index_holder, current_score)
                        else:
                                pass
                        # del last value before reformatting
                        board.pop()
                        # need to write new scores back to file
                        with open("luigi_leaders.txt", mode='w') as \
                             new_leads:
                                # del new line characters from last document
                                for each in board:
                                        each = ':'.join(each)
                                # reapply new line character for all
                                # but last index
                                for i in range(len(board)):
                                        if board[i] == board[-1]:
                                                board[i] = \
                                                         ':'.join(board[i])
                                                pass
                                        else:
                                                board[i][2] = \
                                                            board[i][2] + \
                                                            '\n'
                                                board[i] = \
                                                         ':'.join(board[i])
                                for each in board:
                                        new_leads.write(each)
                with open("game_status.txt", mode='w') as status:
                        status.write("completed")
                leaderboard_update("luigi")
                with open("visibility.txt", mode='w') as vision:
                        vision.write("visible")
                popup.shape("../final_project_fall_2021/" \
                            "slider_puzzle_project_fall2021_assets/" \
                            "Resources/winner.gif")
                popup.showturtle()
                if check == "completed":
                        pass
        elif score[1] >= score[2] and turtle_tracker != locations:
                with open("visibility.txt", mode='w') as vision:
                        vision.write("visible")
                popup.shape("../final_project_fall_2021/" \
                            "slider_puzzle_project_fall2021_assets/" \
                            "Resources/Lose.gif")
                popup.showturtle()
                
    meta_reader('luigi')  
    ts = turtle.Screen()
    turts = turtle.Turtle()
    scorekeep = turtle.Turtle()
    score_present = turtle.Turtle()
    leaders = turtle.Turtle()
    splash = turtle.Turtle()
    popup = turtle.Turtle()
    blank = turtle.Turtle()
    tile_2 = turtle.Turtle()
    tile_3 = turtle.Turtle()
    tile_4 = turtle.Turtle()
    tile_5 = turtle.Turtle()
    tile_6 = turtle.Turtle()
    tile_7 = turtle.Turtle()
    tile_2 = turtle.Turtle()
    tile_8 = turtle.Turtle()
    tile_9 = turtle.Turtle()
    blank.hideturtle()
    tile_2.hideturtle()
    tile_3.hideturtle()
    tile_4.hideturtle()
    tile_5.hideturtle()
    tile_6.hideturtle()
    tile_7.hideturtle()
    tile_8.hideturtle()
    tile_9.hideturtle()
    thumbnail("luigi")
    score_presenter()
    randomizer = random_locations("luigi")
    ts.addshape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "winner.gif")
    ts.addshape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "Lose.gif")
    ts.addshape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "quitmsg.gif")
    ts.addshape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "file_error.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "luigi/blank.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "luigi/2.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "luigi/3.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "luigi/4.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "luigi/5.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "luigi/6.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "luigi/7.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "luigi/8.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "luigi/9.gif")
    blank.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "luigi/blank.gif")
    blank.penup()
    blank.setpos(randomizer[0][0], randomizer[0][1])
    
    tile_2.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "luigi/2.gif")
    tile_2.penup()
    tile_2.setpos(randomizer[1][0], randomizer[1][1])
    tile_3.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "luigi/3.gif")
    tile_3.penup()
    tile_3.setpos(randomizer[2][0], randomizer[2][1])
    tile_4.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "luigi/4.gif")
    tile_4.penup()
    tile_4.setpos(randomizer[3][0], randomizer[3][1])
    tile_5.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "luigi/5.gif")
    tile_5.penup()
    tile_5.setpos(randomizer[4][0], randomizer[4][1])
    tile_6.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "luigi/6.gif")
    tile_6.penup()
    tile_6.setpos(randomizer[5][0], randomizer[5][1])
    tile_7.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "luigi/7.gif")
    tile_7.penup()
    tile_7.setpos(randomizer[6][0], randomizer[6][1])
    tile_8.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "luigi/8.gif")
    tile_8.penup()
    tile_8.setpos(randomizer[7][0], randomizer[7][1])
    tile_9.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "luigi/9.gif")
    tile_9.penup()
    tile_9.setpos(randomizer[8][0], randomizer[8][1])
    PositionService.set_position(blank.xcor(), blank.ycor())
    time.sleep(4)
    blank.showturtle()
    tile_2.showturtle()
    tile_3.showturtle()
    tile_4.showturtle()
    tile_5.showturtle()
    tile_6.showturtle()
    tile_7.showturtle()
    tile_8.showturtle()
    tile_9.showturtle()
    #if file missing, write blank version
    if not os.path.exists('luigi_leaders.txt'):
        open('luigi_leaders.txt', mode='w').close()
    with open("game_status.txt", mode='w') as status:
            status.write("ongoing")
    leaderboard_update("luigi")
    ts.onclick(click_luigi)

def mario_game(username, moves):
    def click_sixteen(x, y):
        turtles = [blank, tile_2, tile_3, tile_4, tile_5, tile_6, tile_7, \
                   tile_8, tile_9, tile_10, tile_11, tile_12, tile_13, \
                   tile_14, tile_15, tile_16]
        vision = visibility_check()
        blank_x = PositionService.get_position_x()
        blank_y = PositionService.get_position_y()
        quit_x = 255
        quit_y = -250
        load_x = 142.5
        load_y = -249.5
        reset_x = 50
        reset_y = -250
        if vision == True:
                if x <= 400 and x >= -400 and y <= 400 and y >= -400:
                        popup.hideturtle()
                        with open("visibility.txt", mode='w') as vision:
                                vision.write('invisible')
        else:
                # Quit button
                if x >= (quit_x - 60) and x <= (quit_x + 60) \
                   and y >= (quit_y - 25) and y <= (quit_y + 25):
                    with open("visibility.txt", mode='w') as vision:
                            vision.write("visible")
                    with open("game_status.txt", mode='w') as status:
                        status.write("ongoing")
                    popup.shape("../final_project_fall_2021/" \
                                "slider_puzzle_project_fall2021_assets/" \
                                "Resources/quitmsg.gif")
                    popup.showturtle()
                    time.sleep(5)
                    turtle.bye()
                # Load button
                elif x >= (load_x - 37.5) and x <= (load_x + 37.5) \
                   and y >= (load_y - 37.5) and y <= (load_y + 37.5):
                    with open("visibility.txt", mode='w') as vision:
                            vision.write("invisible")
                    with open("game_status.txt", mode='w') as status:
                            status.write("completed")
                    new_puzzle = ts.textinput("5001 Puzzle Slide - Load", \
                                              "Which puzzle would you" \
                                              " like to switch" \
                                              " to?\nOptions:\nMario\n" \
                                              "Luigi\nYoshi\nSmiley\n" \
                                              "Fifteen")
                    new_puzzle = new_puzzle.lower()
                    puzzle_validation(new_puzzle)
                    turts.hideturtle()
                    # Hide all relevant turtles, clear board
                    for each in turtles:
                        each.hideturtle()
                    # Choose new game, location and controls
                    game_picker(new_puzzle, username, moves)
                    with open("scorekeeper.txt", mode='w') as new_score:
                        current_score = [f'{username}', '0', f'{moves}']
                        current_score = ":".join(current_score)
                        new_score.write(current_score)
                    score_presenter()
                # Reset button
                elif x >= (reset_x - 40) and x <= (reset_x + 40) \
                   and y >= (reset_y - 40) and y <= (reset_y + 40):
                    with open("game_status.txt", mode='w') as status:
                            status.write("completed")
                    locations = [[-3, -72], [-101, -72], [-199, -72], \
                                 [-297, -72], [-3, 26], [-101, 26], \
                                 [-199, 26], [-297, 26], [-3, 124], \
                                 [-101, 124], [-199, 124], [-297, 124], \
                                 [-3, 222], [-101, 222], [-199, 222], \
                                 [-297, 222]]
                    score = 0
                    blank.setpos(locations[0][0], locations[0][1])
                    PositionService.set_position(locations[0][0], \
                                                 locations[0][1])
                    tile_2.setpos(locations[1][0], locations[1][1])
                    tile_3.setpos(locations[2][0], locations[2][1])
                    tile_4.setpos(locations[3][0], locations[3][1])
                    tile_5.setpos(locations[4][0], locations[4][1])
                    tile_6.setpos(locations[5][0], locations[5][1])
                    tile_7.setpos(locations[6][0], locations[6][1])
                    tile_8.setpos(locations[7][0], locations[7][1])
                    tile_9.setpos(locations[8][0], locations[8][1])
                    tile_10.setpos(locations[9][0], locations[9][1])
                    tile_11.setpos(locations[10][0], locations[10][1])
                    tile_12.setpos(locations[11][0], locations[11][1])
                    tile_13.setpos(locations[12][0], locations[12][1])
                    tile_14.setpos(locations[13][0], locations[13][1])
                    tile_15.setpos(locations[14][0], locations[14][1])
                    tile_16.setpos(locations[15][0], locations[15][1])
                    score_check()
                # Bottom Right White Tile
                elif blank_x == -3 and blank_y == -72:
                    # Go Bot Left
                    if x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-101, -72): 
                                each.setpos(-3, -72)
                                blank.setpos(-101, -72)
                                PositionService.set_position(-101, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Right
                    elif x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48): 
                        for each in turtles:
                            if each.pos() == (-3, 26):
                                each.setpos(-3, -72)
                                blank.setpos(-3, 26)
                                PositionService.set_position(-3, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Mid Bot Right White Tile
                elif blank_x == -101 and blank_y == -72:
                    # Go Bot Right 1/3
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-3, -72):
                                each.setpos(-101, -72)
                                blank.setpos(-3, -72)
                                PositionService.set_position(-3, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Middle 2/3
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 26):
                                each.setpos(-101, -72)
                                blank.setpos(-101, 26)
                                PositionService.set_position(-101, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Bot Left 3/3
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-199, -72):
                                each.setpos(-101, -72)
                                blank.setpos(-199, -72)
                                PositionService.set_position(-199, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Mid Bot Left White Tile
                elif blank_x == -199 and blank_y == -72:
                    # Go Bot Mid
                    if x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-101, -72):
                                each.setpos(-199, -72)
                                blank.setpos(-101, -72)
                                PositionService.set_position(-101, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Low Mid Left
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 26):
                                each.setpos(-199, -72)
                                blank.setpos(-199, 26)
                                PositionService.set_position(-199, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Low Mid Left
                    elif x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-297, -72):
                                each.setpos(-199, -72)
                                blank.setpos(-297, -72)
                                PositionService.set_position(-297, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Bot Left White Tile
                elif blank_x == -297 and blank_y == -72:
                    # Go Bot Left Mid
                    if x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-199, -72):
                                each.setpos(-297, -72)
                                blank.setpos(-199, -72)
                                PositionService.set_position(-199, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Mid Left
                    elif x <= (-297 + 48) and x >= (-297 -48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 26):
                                each.setpos(-297, -72)
                                blank.setpos(-297, 26)
                                PositionService.set_position(-297, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Middle Right White Tile
                elif blank_x == -3 and blank_y == 26:
                    # Go Bot Right 1/3
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-3, -72):
                                each.setpos(-3, 26)
                                blank.setpos(-3, -72)
                                PositionService.set_position(-3, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Middle 2/3
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 26):
                                each.setpos(-3, 26)
                                blank.setpos(-101, 26)
                                PositionService.set_position(-101, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Right 3/3
                    elif x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 124):
                                each.setpos(-3, 26)
                                blank.setpos(-3, 124)
                                PositionService.set_position(-3, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Center White Tile
                elif blank_x == -101 and blank_y == 26:
                    # Go Mid Right 1/4
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 26):
                                each.setpos(-101, 26)
                                blank.setpos(-3, 26)
                                PositionService.set_position(-3, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Bot Mid 2/4
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-101, -72): 
                                each.setpos(-101, 26)
                                blank.setpos(-101, -72)
                                PositionService.set_position(-101, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Mid Left 3/4
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 26): 
                                each.setpos(-101, 26)
                                blank.setpos(-199, 26)
                                PositionService.set_position(-199, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Mid 4/4
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 124): 
                                each.setpos(-101, 26)
                                blank.setpos(-101, 124)
                                PositionService.set_position(-101, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Middle Left White Tile
                elif blank_x == -199 and blank_y == 26:
                    # Go Bot Left 1/3
                    if x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-199, -72):
                                each.setpos(-199, 26)
                                blank.setpos(-199, -72)
                                PositionService.set_position(-199, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Middle 2/3
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 26):
                                each.setpos(-199, 26)
                                blank.setpos(-101, 26)
                                PositionService.set_position(-101, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Middle 2/3
                    elif x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 26):
                                each.setpos(-199, 26)
                                blank.setpos(-297, 26)
                                PositionService.set_position(-297, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Left 3/3
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 124):
                                each.setpos(-199, 26)
                                blank.setpos(-199, 124)
                                PositionService.set_position(-199, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Middle Left White Tile
                elif blank_x == -297 and blank_y == 26:
                    # Go Upper Left 1/3
                    if x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 124):
                                each.setpos(-297, 26)
                                blank.setpos(-297, 124)
                                PositionService.set_position(-297, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Bot Left 2/3
                    elif x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-297, -72):
                                each.setpos(-297, 26)
                                blank.setpos(-297, -72)
                                PositionService.set_position(-297, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                    # Go Bot Middle 3/3
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 26):
                                each.setpos(-297, 26)
                                blank.setpos(-199, 26)
                                PositionService.set_position(-199, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Mid Top Right White Tile
                elif blank_x == -3 and blank_y == 124:
                    # Go Lower Mid Right 1/3
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 26):
                                each.setpos(-3, 124)
                                blank.setpos(-3, 26)
                                PositionService.set_position(-3, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Upper Mid R 2/3
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 124):
                                each.setpos(-3, 124)
                                blank.setpos(-101, 124)
                                PositionService.set_position(-101, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Right C 1/3
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 222):
                                each.setpos(-3, 124)
                                blank.setpos(-3, 222)
                                PositionService.set_position(-3, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Upper Mid R White Tile
                elif blank_x == -101 and blank_y == 124:
                    # Go Top Right M 1/4
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 124):
                                each.setpos(-101, 124)
                                blank.setpos(-3, 124)
                                PositionService.set_position(-3, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Low Mid Left 2/4
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 26):
                                each.setpos(-101, 124)
                                blank.setpos(-101, 26)
                                PositionService.set_position(-101, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Upper Mid Left 3/4
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 124):
                                each.setpos(-101, 124)
                                blank.setpos(-199, 124)
                                PositionService.set_position(-199, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Upper Mid Left 3/4
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 222):
                                each.setpos(-101, 124)
                                blank.setpos(-101, 222)
                                PositionService.set_position(-101, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Upper Center left White Tile
                elif blank_x == -199 and blank_y == 124:
                    # Go Mid Left 1/4
                    if x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48): 
                        for each in turtles:
                            if each.pos() == (-199, 26):
                                each.setpos(-199, 124)
                                blank.setpos(-199, 26)
                                PositionService.set_position(-199, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Bot Center 2/4
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48): 
                        for each in turtles:
                            if each.pos() == (-101, 124):
                                each.setpos(-199, 124)
                                blank.setpos(-101, 124)
                                PositionService.set_position(-101, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Middle L 3/4
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48): 
                        for each in turtles:
                            if each.pos() == (-199, 222):
                                each.setpos(-199, 124)
                                blank.setpos(-199, 222)
                                PositionService.set_position(-199, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Upper L 4/4
                    elif x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 124):
                                each.setpos(-199, 124)
                                blank.setpos(-297, 124)
                                PositionService.set_position(-297, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Top Left Side White Tile
                elif blank_x == -297 and blank_y == 124:
                    # Go Low Left Side 1/3
                    if x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 26):
                                each.setpos(-297, 124)
                                blank.setpos(-297, 26)
                                PositionService.set_position(-297, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Up Left Center 2/3
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 124):
                                each.setpos(-297, 124)
                                blank.setpos(-199, 124)
                                PositionService.set_position(-199, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Left Corner 2/3
                    elif x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 222):
                                each.setpos(-297, 124)
                                blank.setpos(-297, 222)
                                PositionService.set_position(-297, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Top Right Corner White Tile
                elif blank_x == -3 and blank_y == 222:
                    # Go Low Left Side 1/2
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 124):
                                each.setpos(-3, 222)
                                blank.setpos(-3, 124)
                                PositionService.set_position(-3, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Up Left Center 2/2
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 222):
                                each.setpos(-3, 222)
                                blank.setpos(-101, 222)
                                PositionService.set_position(-101, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Top Right Mid White Tile
                elif blank_x == -101 and blank_y == 222:
                    # Go Top Right Corn 1/3
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 222):
                                each.setpos(-101, 222)
                                blank.setpos(-3, 222)
                                PositionService.set_position(-3, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Upper R Center 2/3
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 124):
                                each.setpos(-101, 222)
                                blank.setpos(-101, 124)
                                PositionService.set_position(-101, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top L Center 3/3
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 222):
                                each.setpos(-101, 222)
                                blank.setpos(-199, 222)
                                PositionService.set_position(-199, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Top Left Mid White Tile
                elif blank_x == -199 and blank_y == 222:
                    # Go Top Right Cent 1/3
                    if x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 222):
                                each.setpos(-199, 222)
                                blank.setpos(-101, 222)
                                PositionService.set_position(-101, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Upper R Center 2/3
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 124):
                                each.setpos(-199, 222)
                                blank.setpos(-199, 124)
                                PositionService.set_position(-199, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top L Center 3/3
                    elif x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 222):
                                each.setpos(-199, 222)
                                blank.setpos(-297, 222)
                                PositionService.set_position(-297, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Top Left Corner
                elif blank_x == -297 and blank_y == 222:
                    # Go Upper Left Side 1/2
                    if x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 124):
                                each.setpos(-297, 222)
                                blank.setpos(-297, 124)
                                PositionService.set_position(-297, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top L Center 2/2
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 222):
                                each.setpos(-297, 222)
                                blank.setpos(-199, 222)
                                PositionService.set_position(-199, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_checker()
                
    def thumbnail(image: str):
        screen = turtle.getscreen()
        turts.penup()
        turts.hideturtle()
        turts.setposition(290, 260)
        pic = "../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              f"{image}/{image}_thumbnail.gif"
        screen.addshape(pic)
        turts.shape(pic)
        turts.showturtle()
        
    def leaderboard_update(game_name):
        style = ('Calibri', 24, 'bold')
        with open(f"{game_name}_leaders.txt", mode='r') as leaderboard:
                board = leaderboard.readlines()
                for i in range(len(board)):
                        board[i] = board[i].replace("\n", "")
                        board[i] = board[i].split(':')
        leaders.pencolor("#350A0A")
        leaders.speed(0)
        leaders.penup()
        leaders.hideturtle()
        leaders.setpos(110, 210)
        leaders.fillcolor("beige")
        leaders.begin_fill()
        leaders.setheading(270)
        leaders.forward(300)
        leaders.left(90)
        leaders.forward(150)
        leaders.left(90)
        leaders.forward(300)
        leaders.left(90)
        leaders.forward(150)
        leaders.left(90)
        leaders.end_fill()
        leaders.setpos(110, 160)
        for i in range(len(board)):
                score = f"{board[i][1]}: {board[i][0]}"
                leaders.write(score, font=style, align='left')
                leaders.forward(60)
                
    def score_presenter():
        score_present.speed(0)
        score_present.hideturtle()
        score_present.penup()
        score_present.setpos(-188, -267)
        score_present.fillcolor('beige')
        score_present.begin_fill()
        score_present.forward(100)
        score_present.left(90)
        score_present.forward(50)
        score_present.left(90)
        score_present.forward(103)
        score_present.left(90)
        score_present.forward(50)
        score_present.left(90)
        score_present.forward(3)
        score_present.end_fill()
        score_present.pencolor("#350A0A")
        style = ('Calibri', 26, 'bold')
        with open("scorekeeper.txt", mode='r') as score:
            scorer = score.readline()
            scores = scorer.split(":")
            score_present.write(f"{scores[1]}", font=style, align='left')

    def score_check():
        turtles = [blank, tile_2, tile_3, tile_4, tile_5, tile_6, tile_7, \
                   tile_8, tile_9, tile_10, tile_11, tile_12, tile_13, \
                   tile_14, tile_15, tile_16]
        locations = [[-3, -72], [-101, -72], [-199, -72], [-297, -72], \
                     [-3, 26], [-101, 26], [-199, 26], [-297, 26], \
                     [-3, 124], [-101, 124], [-199, 124], [-297, 124], \
                     [-3, 222], [-101, 222], [-199, 222], [-297, 222]]
        turtle_tracker = []
        for each in turtles:
            turtle_tracker.append(list(each.pos()))
        with open("scorekeeper.txt", mode="r") as scoreboard:
            current_score = scoreboard.readline()
            score = current_score.split(":")
            score[1] = int(score[1])
            score[2] = int(score[2])
            # If the score is less or equal to limit and locations
            # match solved
        if score[1] <= score[2] and turtle_tracker == locations:
            with open("game_status.txt") as status:
                    check = status.readline()
            if check == "ongoing":
                # making the current score a variable
                with open("scorekeeper.txt", mode='r') as \
                     scoreboard:
                        current_score = scoreboard.readline()
                        current_score = current_score.split(":")
                board = []
                # adds all logged scores to board list
                with open("mario_leaders.txt", mode='r') \
                     as leaderboard:
                        board = leaderboard.readlines()
                for i in range(len(board)):
                        board[i] = board[i].replace("\n", "")
                if len(board) == 0:
                        with open("mario_leaders.txt", mode='w') \
                                as empty_board:
                                current_score = ':'.join(current_score)
                                empty_board.write(current_score)
                                        
                elif len(board) < 5:
                        for i in range(len(board)):
                                board[i] = board[i].split(":")
                        # find index where current score is
                        # less than a leader
                        for i in range(len(board)):
                                # skip if score is greater
                                if int(current_score[1]) > int(board[i][1]):
                                        continue
                        # append index, break loop if score <= current line
                                elif int(current_score[1]) <= \
                                     int(board[i][1]):
                                        index_holder = i
                                        break
                        # failsafe if current score > all available
                        if int(current_score[1]) > int(board[-1][1]):
                                board.append(current_score)
                        elif index_holder >= 0:
                                board.insert(index_holder, current_score)
                        else:
                                pass
                        # need to write new scores back to file
                        with open("mario_leaders.txt", mode='w') as \
                             new_leads:
                                # del new line characters from last document
                                for each in board:
                                        each = ':'.join(each)
                                # reapply new line character for all
                                # but last index
                                for i in range(len(board)):
                                        if board[i] == board[-1]:
                                                board[i] = ':'.join(board[i])
                                                pass
                                        else:
                                                board[i][2] = board[i][2] \
                                                              + '\n'
                                                board[i] = \
                                                         ':'.join(board[i])
                                for each in board:
                                        new_leads.write(each)
                        leaderboard_update("mario")
                elif len(board) == 5:
                        for i in range(len(board)):
                                board[i] = board[i].split(":")
                        # find index where current score is less than leader
                        for i in range(len(board)):
                                # skip if score is greater
                                if int(current_score[1]) > int(board[i][1]):
                                        continue
                                # append index, break loop if
                                # score <= current line
                                elif int(current_score[1]) <= \
                                     int(board[i][1]):
                                        index_holder = i
                                        break
                        # failsafe if current score > all available
                        if int(current_score[1]) > int(board[-1][1]):
                                board.append(current_score)
                        elif index_holder >= 0:
                                board.insert(index_holder, current_score)
                        else:
                                pass
                        # del last value before reformatting
                        board.pop()
                        # need to write new scores back to file
                        with open("mario_leaders.txt", mode='w') as \
                             new_leads:
                                # del new line characters from last document
                                for each in board:
                                        each = ':'.join(each)
                                # reapply new line character for all
                                # but last index
                                for i in range(len(board)):
                                        if board[i] == board[-1]:
                                                board[i] = \
                                                         ':'.join(board[i])
                                                pass
                                        else:
                                                board[i][2] = \
                                                            board[i][2] + \
                                                            '\n'
                                                board[i] = \
                                                         ':'.join(board[i])
                                for each in board:
                                        new_leads.write(each)
                with open("game_status.txt", mode='w') as status:
                        status.write("completed")
                leaderboard_update("mario")
                with open("visibility.txt", mode='w') as vision:
                        vision.write("visible")
                popup.shape("../final_project_fall_2021/" \
                            "slider_puzzle_project_fall2021_assets/" \
                            "Resources/winner.gif")
                popup.showturtle()
                if check == "completed":
                        pass
        elif score[1] >= score[2] and turtle_tracker != locations:
                with open("visibility.txt", mode='w') as vision:
                        vision.write("visible")
                popup.shape("../final_project_fall_2021/" \
                            "slider_puzzle_project_fall2021_assets/" \
                            "Resources/Lose.gif")
                popup.showturtle()
                
    meta_reader('mario')
    ts = turtle.Screen()
    turts = turtle.Turtle()
    scorekeep = turtle.Turtle()
    score_present = turtle.Turtle()
    leaders = turtle.Turtle()
    splash = turtle.Turtle()
    popup = turtle.Turtle()
    blank = turtle.Turtle()
    tile_2 = turtle.Turtle()
    tile_3 = turtle.Turtle()
    tile_4 = turtle.Turtle()
    tile_5 = turtle.Turtle()
    tile_6 = turtle.Turtle()
    tile_7 = turtle.Turtle()
    tile_2 = turtle.Turtle()
    tile_8 = turtle.Turtle()
    tile_9 = turtle.Turtle()
    tile_10 = turtle.Turtle()
    tile_11 = turtle.Turtle()
    tile_12 = turtle.Turtle()
    tile_13 = turtle.Turtle()
    tile_14 = turtle.Turtle()
    tile_15 = turtle.Turtle()
    tile_16 = turtle.Turtle()
    blank.hideturtle()
    tile_2.hideturtle()
    tile_3.hideturtle()
    tile_4.hideturtle()
    tile_5.hideturtle()
    tile_6.hideturtle()
    tile_7.hideturtle()
    tile_8.hideturtle()
    tile_9.hideturtle()
    tile_10.hideturtle()
    tile_11.hideturtle()
    tile_12.hideturtle()
    tile_13.hideturtle()
    tile_14.hideturtle()
    tile_15.hideturtle()
    tile_16.hideturtle()
    thumbnail("mario")
    score_presenter()
    randomizer = random_locations("mario")
    ts.addshape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "winner.gif")
    ts.addshape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "Lose.gif")
    ts.addshape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "quitmsg.gif")
    ts.addshape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "file_error.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/blank.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/2.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/3.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/4.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/5.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/6.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/7.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/8.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/9.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/10.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/11.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/12.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/13.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/14.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/15.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/16.gif")
    blank.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/blank.gif")
    blank.penup()
    blank.setpos(randomizer[0][0], randomizer[0][1])
    tile_2.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/2.gif")
    tile_2.penup()
    tile_2.setpos(randomizer[1][0], randomizer[1][1])
    tile_3.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/3.gif")
    tile_3.penup()
    tile_3.setpos(randomizer[2][0], randomizer[2][1])
    tile_4.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/4.gif")
    tile_4.penup()
    tile_4.setpos(randomizer[3][0], randomizer[3][1])
    tile_5.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/5.gif")
    tile_5.penup()
    tile_5.setpos(randomizer[4][0], randomizer[4][1])
    tile_6.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/6.gif")
    tile_6.penup()
    tile_6.setpos(randomizer[5][0], randomizer[5][1])
    tile_7.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/7.gif")
    tile_7.penup()
    tile_7.setpos(randomizer[6][0], randomizer[6][1])
    tile_8.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/8.gif")
    tile_8.penup()
    tile_8.setpos(randomizer[7][0], randomizer[7][1])
    tile_9.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/9.gif")
    tile_9.penup()
    tile_9.setpos(randomizer[8][0], randomizer[8][1])
    tile_10.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/10.gif")
    tile_10.penup()
    tile_10.setpos(randomizer[9][0], randomizer[9][1])
    tile_11.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/11.gif")
    tile_11.penup()
    tile_11.setpos(randomizer[10][0], randomizer[10][1])
    tile_12.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/12.gif")
    tile_12.penup()
    tile_12.setpos(randomizer[11][0], randomizer[11][1])
    tile_13.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/13.gif")
    tile_13.penup()
    tile_13.setpos(randomizer[12][0], randomizer[12][1])
    tile_14.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/14.gif")
    tile_14.penup()
    tile_14.setpos(randomizer[13][0], randomizer[13][1])
    tile_15.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/15.gif")
    tile_15.penup()
    tile_15.setpos(randomizer[14][0], randomizer[14][1])
    tile_16.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "mario/16.gif")
    tile_16.penup()
    tile_16.setpos(randomizer[15][0], randomizer[15][1])
    PositionService.set_position(blank.xcor(), blank.ycor())
    time.sleep(4)
    blank.showturtle()
    tile_2.showturtle()
    tile_3.showturtle()
    tile_4.showturtle()
    tile_5.showturtle()
    tile_6.showturtle()
    tile_7.showturtle()
    tile_8.showturtle()
    tile_9.showturtle()
    tile_10.showturtle()
    tile_11.showturtle()
    tile_12.showturtle()
    tile_13.showturtle()
    tile_14.showturtle()
    tile_15.showturtle()
    tile_16.showturtle()
    #if file missing, write blank version
    if not os.path.exists('mario_leaders.txt'):
        open('mario_leaders.txt', mode='w').close()
    with open("game_status.txt", mode='w') as status:
            status.write("ongoing")
    popup.hideturtle()
    with open("visibility.txt", mode='w') as vision:
            vision.write('invisible')
    leaderboard_update("mario")
    ts.onclick(click_sixteen)
    
def smiley_game(username, moves):
    def click_sixteen(x, y):
        turtles = [blank, tile_2, tile_3, tile_4, tile_5, tile_6, tile_7, \
                   tile_8, tile_9, tile_10, tile_11, tile_12, tile_13, \
                   tile_14, tile_15, tile_16]
        vision = visibility_check()
        blank_x = PositionService.get_position_x()
        blank_y = PositionService.get_position_y()
        quit_x = 255
        quit_y = -250
        load_x = 142.5
        load_y = -249.5
        reset_x = 50
        reset_y = -250
        if vision == True:
                if x <= 400 and x >= -400 and y <= 400 and y >= -400:
                        popup.hideturtle()
                        with open("visibility.txt", mode='w') as vision:
                                vision.write('invisible')
        else:
                # Quit button
                if x >= (quit_x - 60) and x <= (quit_x + 60) \
                   and y >= (quit_y - 25) and y <= (quit_y + 25):
                    with open("visibility.txt", mode='w') as vision:
                            vision.write("visible")
                    with open("game_status.txt", mode='w') as status:
                        status.write("ongoing")
                    popup.shape("../final_project_fall_2021/" \
                                "slider_puzzle_project_fall2021_assets/" \
                                "Resources/quitmsg.gif")
                    popup.showturtle()
                    time.sleep(5)
                    turtle.bye()
                # Load button
                elif x >= (load_x - 37.5) and x <= (load_x + 37.5) \
                   and y >= (load_y - 37.5) and y <= (load_y + 37.5):
                    with open("visibility.txt", mode='w') as vision:
                            vision.write("invisible")
                    with open("game_status.txt", mode='w') as status:
                            status.write("completed")
                    new_puzzle = ts.textinput("5001 Puzzle Slide - Load", \
                                              "Which puzzle would you" \
                                              " like to switch" \
                                              " to?\nOptions:\nMario\n" \
                                              "Luigi\nYoshi\nSmiley\n" \
                                              "Fifteen")
                    new_puzzle = new_puzzle.lower()
                    puzzle_validation(new_puzzle)
                    turts.hideturtle()
                    # Hide all relevant turtles, clear board
                    for each in turtles:
                        each.hideturtle()
                    # Choose new game, location and controls
                    game_picker(new_puzzle, username, moves)
                    with open("scorekeeper.txt", mode='w') as new_score:
                        current_score = [f'{username}', '0', f'{moves}']
                        current_score = ":".join(current_score)
                        new_score.write(current_score)
                    score_presenter()
                # Reset button
                elif x >= (reset_x - 40) and x <= (reset_x + 40) \
                   and y >= (reset_y - 40) and y <= (reset_y + 40):
                    with open("game_status.txt", mode='w') as status:
                            status.write("completed")
                    locations = [[-3, -72], [-101, -72], [-199, -72], \
                                 [-297, -72], [-3, 26], [-101, 26], \
                                 [-199, 26], [-297, 26], [-3, 124], \
                                 [-101, 124], [-199, 124], [-297, 124], \
                                 [-3, 222], [-101, 222], [-199, 222], \
                                 [-297, 222]]
                    score = 0
                    blank.setpos(locations[0][0], locations[0][1])
                    PositionService.set_position(locations[0][0], \
                                                 locations[0][1])
                    tile_2.setpos(locations[1][0], locations[1][1])
                    tile_3.setpos(locations[2][0], locations[2][1])
                    tile_4.setpos(locations[3][0], locations[3][1])
                    tile_5.setpos(locations[4][0], locations[4][1])
                    tile_6.setpos(locations[5][0], locations[5][1])
                    tile_7.setpos(locations[6][0], locations[6][1])
                    tile_8.setpos(locations[7][0], locations[7][1])
                    tile_9.setpos(locations[8][0], locations[8][1])
                    tile_10.setpos(locations[9][0], locations[9][1])
                    tile_11.setpos(locations[10][0], locations[10][1])
                    tile_12.setpos(locations[11][0], locations[11][1])
                    tile_13.setpos(locations[12][0], locations[12][1])
                    tile_14.setpos(locations[13][0], locations[13][1])
                    tile_15.setpos(locations[14][0], locations[14][1])
                    tile_16.setpos(locations[15][0], locations[15][1])
                    score_check()
                # Bottom Right White Tile
                elif blank_x == -3 and blank_y == -72:
                    # Go Bot Left
                    if x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-101, -72): 
                                each.setpos(-3, -72)
                                blank.setpos(-101, -72)
                                PositionService.set_position(-101, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Right
                    elif x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48): 
                        for each in turtles:
                            if each.pos() == (-3, 26):
                                each.setpos(-3, -72)
                                blank.setpos(-3, 26)
                                PositionService.set_position(-3, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Mid Bot Right White Tile
                elif blank_x == -101 and blank_y == -72:
                    # Go Bot Right 1/3
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-3, -72):
                                each.setpos(-101, -72)
                                blank.setpos(-3, -72)
                                PositionService.set_position(-3, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Middle 2/3
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 26):
                                each.setpos(-101, -72)
                                blank.setpos(-101, 26)
                                PositionService.set_position(-101, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Bot Left 3/3
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-199, -72):
                                each.setpos(-101, -72)
                                blank.setpos(-199, -72)
                                PositionService.set_position(-199, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Mid Bot Left White Tile
                elif blank_x == -199 and blank_y == -72:
                    # Go Bot Mid
                    if x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-101, -72):
                                each.setpos(-199, -72)
                                blank.setpos(-101, -72)
                                PositionService.set_position(-101, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Low Mid Left
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 26):
                                each.setpos(-199, -72)
                                blank.setpos(-199, 26)
                                PositionService.set_position(-199, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Low Mid Left
                    elif x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-297, -72):
                                each.setpos(-199, -72)
                                blank.setpos(-297, -72)
                                PositionService.set_position(-297, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Bot Left White Tile
                elif blank_x == -297 and blank_y == -72:
                    # Go Bot Left Mid
                    if x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-199, -72):
                                each.setpos(-297, -72)
                                blank.setpos(-199, -72)
                                PositionService.set_position(-199, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Mid Left
                    elif x <= (-297 + 48) and x >= (-297 -48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 26):
                                each.setpos(-297, -72)
                                blank.setpos(-297, 26)
                                PositionService.set_position(-297, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Middle Right White Tile
                elif blank_x == -3 and blank_y == 26:
                    # Go Bot Right 1/3
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-3, -72):
                                each.setpos(-3, 26)
                                blank.setpos(-3, -72)
                                PositionService.set_position(-3, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Middle 2/3
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 26):
                                each.setpos(-3, 26)
                                blank.setpos(-101, 26)
                                PositionService.set_position(-101, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Right 3/3
                    elif x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 124):
                                each.setpos(-3, 26)
                                blank.setpos(-3, 124)
                                PositionService.set_position(-3, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Center White Tile
                elif blank_x == -101 and blank_y == 26:
                    # Go Mid Right 1/4
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 26):
                                each.setpos(-101, 26)
                                blank.setpos(-3, 26)
                                PositionService.set_position(-3, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Bot Mid 2/4
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-101, -72): 
                                each.setpos(-101, 26)
                                blank.setpos(-101, -72)
                                PositionService.set_position(-101, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Mid Left 3/4
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 26): 
                                each.setpos(-101, 26)
                                blank.setpos(-199, 26)
                                PositionService.set_position(-199, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Mid 4/4
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 124): 
                                each.setpos(-101, 26)
                                blank.setpos(-101, 124)
                                PositionService.set_position(-101, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Middle Left White Tile
                elif blank_x == -199 and blank_y == 26:
                    # Go Bot Left 1/3
                    if x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-199, -72):
                                each.setpos(-199, 26)
                                blank.setpos(-199, -72)
                                PositionService.set_position(-199, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Middle 2/3
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 26):
                                each.setpos(-199, 26)
                                blank.setpos(-101, 26)
                                PositionService.set_position(-101, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Middle 2/3
                    elif x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 26):
                                each.setpos(-199, 26)
                                blank.setpos(-297, 26)
                                PositionService.set_position(-297, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Left 3/3
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 124):
                                each.setpos(-199, 26)
                                blank.setpos(-199, 124)
                                PositionService.set_position(-199, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Middle Left White Tile
                elif blank_x == -297 and blank_y == 26:
                    # Go Upper Left 1/3
                    if x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 124):
                                each.setpos(-297, 26)
                                blank.setpos(-297, 124)
                                PositionService.set_position(-297, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Bot Left 2/3
                    elif x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-297, -72):
                                each.setpos(-297, 26)
                                blank.setpos(-297, -72)
                                PositionService.set_position(-297, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                    # Go Bot Middle 3/3
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 26):
                                each.setpos(-297, 26)
                                blank.setpos(-199, 26)
                                PositionService.set_position(-199, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Mid Top Right White Tile
                elif blank_x == -3 and blank_y == 124:
                    # Go Lower Mid Right 1/3
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 26):
                                each.setpos(-3, 124)
                                blank.setpos(-3, 26)
                                PositionService.set_position(-3, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Upper Mid R 2/3
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 124):
                                each.setpos(-3, 124)
                                blank.setpos(-101, 124)
                                PositionService.set_position(-101, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Right C 1/3
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 222):
                                each.setpos(-3, 124)
                                blank.setpos(-3, 222)
                                PositionService.set_position(-3, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Upper Mid R White Tile
                elif blank_x == -101 and blank_y == 124:
                    # Go Top Right M 1/4
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 124):
                                each.setpos(-101, 124)
                                blank.setpos(-3, 124)
                                PositionService.set_position(-3, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Low Mid Left 2/4
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 26):
                                each.setpos(-101, 124)
                                blank.setpos(-101, 26)
                                PositionService.set_position(-101, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Upper Mid Left 3/4
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 124):
                                each.setpos(-101, 124)
                                blank.setpos(-199, 124)
                                PositionService.set_position(-199, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Upper Mid Left 3/4
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 222):
                                each.setpos(-101, 124)
                                blank.setpos(-101, 222)
                                PositionService.set_position(-101, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Upper Center left White Tile
                elif blank_x == -199 and blank_y == 124:
                    # Go Mid Left 1/4
                    if x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48): 
                        for each in turtles:
                            if each.pos() == (-199, 26):
                                each.setpos(-199, 124)
                                blank.setpos(-199, 26)
                                PositionService.set_position(-199, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Bot Center 2/4
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48): 
                        for each in turtles:
                            if each.pos() == (-101, 124):
                                each.setpos(-199, 124)
                                blank.setpos(-101, 124)
                                PositionService.set_position(-101, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Middle L 3/4
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48): 
                        for each in turtles:
                            if each.pos() == (-199, 222):
                                each.setpos(-199, 124)
                                blank.setpos(-199, 222)
                                PositionService.set_position(-199, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Upper L 4/4
                    elif x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 124):
                                each.setpos(-199, 124)
                                blank.setpos(-297, 124)
                                PositionService.set_position(-297, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Top Left Side White Tile
                elif blank_x == -297 and blank_y == 124:
                    # Go Low Left Side 1/3
                    if x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 26):
                                each.setpos(-297, 124)
                                blank.setpos(-297, 26)
                                PositionService.set_position(-297, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Up Left Center 2/3
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 124):
                                each.setpos(-297, 124)
                                blank.setpos(-199, 124)
                                PositionService.set_position(-199, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Left Corner 2/3
                    elif x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 222):
                                each.setpos(-297, 124)
                                blank.setpos(-297, 222)
                                PositionService.set_position(-297, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Top Right Corner White Tile
                elif blank_x == -3 and blank_y == 222:
                    # Go Low Left Side 1/2
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 124):
                                each.setpos(-3, 222)
                                blank.setpos(-3, 124)
                                PositionService.set_position(-3, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Up Left Center 2/2
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 222):
                                each.setpos(-3, 222)
                                blank.setpos(-101, 222)
                                PositionService.set_position(-101, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Top Right Mid White Tile
                elif blank_x == -101 and blank_y == 222:
                    # Go Top Right Corn 1/3
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 222):
                                each.setpos(-101, 222)
                                blank.setpos(-3, 222)
                                PositionService.set_position(-3, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Upper R Center 2/3
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 124):
                                each.setpos(-101, 222)
                                blank.setpos(-101, 124)
                                PositionService.set_position(-101, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top L Center 3/3
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 222):
                                each.setpos(-101, 222)
                                blank.setpos(-199, 222)
                                PositionService.set_position(-199, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Top Left Mid White Tile
                elif blank_x == -199 and blank_y == 222:
                    # Go Top Right Cent 1/3
                    if x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 222):
                                each.setpos(-199, 222)
                                blank.setpos(-101, 222)
                                PositionService.set_position(-101, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Upper R Center 2/3
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 124):
                                each.setpos(-199, 222)
                                blank.setpos(-199, 124)
                                PositionService.set_position(-199, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top L Center 3/3
                    elif x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 222):
                                each.setpos(-199, 222)
                                blank.setpos(-297, 222)
                                PositionService.set_position(-297, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Top Left Corner
                elif blank_x == -297 and blank_y == 222:
                    # Go Upper Left Side 1/2
                    if x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 124):
                                each.setpos(-297, 222)
                                blank.setpos(-297, 124)
                                PositionService.set_position(-297, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top L Center 2/2
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 222):
                                each.setpos(-297, 222)
                                blank.setpos(-199, 222)
                                PositionService.set_position(-199, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                
    def thumbnail(image: str):
        screen = turtle.getscreen()
        turts.penup()
        turts.hideturtle()
        turts.setposition(290, 260)
        pic = "../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              f"{image}/{image}_thumbnail.gif"
        screen.addshape(pic)
        turts.shape(pic)
        turts.showturtle()
        
    def leaderboard_update(game_name):
        style = ('Calibri', 24, 'bold')
        with open(f"{game_name}_leaders.txt", mode='r') as leaderboard:
                board = leaderboard.readlines()
                for i in range(len(board)):
                        board[i] = board[i].replace("\n", "")
                        board[i] = board[i].split(':')
        leaders.pencolor("#350A0A")
        leaders.speed(0)
        leaders.penup()
        leaders.hideturtle()
        leaders.setpos(110, 210)
        leaders.fillcolor("beige")
        leaders.begin_fill()
        leaders.setheading(270)
        leaders.forward(300)
        leaders.left(90)
        leaders.forward(150)
        leaders.left(90)
        leaders.forward(300)
        leaders.left(90)
        leaders.forward(150)
        leaders.left(90)
        leaders.end_fill()
        leaders.setpos(110, 160)
        for i in range(len(board)):
                score = f"{board[i][1]}: {board[i][0]}"
                leaders.write(score, font=style, align='left')
                leaders.forward(60)
                
    def score_presenter():
        score_present.speed(0)
        score_present.hideturtle()
        score_present.penup()
        score_present.setpos(-188, -267)
        score_present.fillcolor('beige')
        score_present.begin_fill()
        score_present.forward(100)
        score_present.left(90)
        score_present.forward(50)
        score_present.left(90)
        score_present.forward(103)
        score_present.left(90)
        score_present.forward(50)
        score_present.left(90)
        score_present.forward(3)
        score_present.end_fill()
        score_present.pencolor("#350A0A")
        style = ('Calibri', 26, 'bold')
        with open("scorekeeper.txt", mode='r') as score:
            scorer = score.readline()
            scores = scorer.split(":")
            score_present.write(f"{scores[1]}", font=style, align='left')

    def score_check():
        turtles = [blank, tile_2, tile_3, tile_4, tile_5, tile_6, tile_7, \
                   tile_8, tile_9, tile_10, tile_11, tile_12, tile_13, \
                   tile_14, tile_15, tile_16]
        locations = [[-3, -72], [-101, -72], [-199, -72], [-297, -72], \
                     [-3, 26], [-101, 26], [-199, 26], [-297, 26], \
                     [-3, 124], [-101, 124], [-199, 124], [-297, 124], \
                     [-3, 222], [-101, 222], [-199, 222], [-297, 222]]
        turtle_tracker = []
        for each in turtles:
            turtle_tracker.append(list(each.pos()))
        with open("scorekeeper.txt", mode="r") as scoreboard:
            current_score = scoreboard.readline()
            score = current_score.split(":")
            score[1] = int(score[1])
            score[2] = int(score[2])
            # If the score is less or equal to limit and locations
            # match solved
        if score[1] <= score[2] and turtle_tracker == locations:
            with open("game_status.txt") as status:
                    check = status.readline()
            if check == "ongoing":
                # making the current score a variable
                with open("scorekeeper.txt", mode='r') as \
                     scoreboard:
                        current_score = scoreboard.readline()
                        current_score = current_score.split(":")
                board = []
                # adds all logged scores to board list
                with open("smiley_leaders.txt", mode='r') \
                     as leaderboard:
                        board = leaderboard.readlines()
                for i in range(len(board)):
                        board[i] = board[i].replace("\n", "")
                if len(board) == 0:
                        with open("smiley_leaders.txt", mode='w') \
                                as empty_board:
                                current_score = ':'.join(current_score)
                                empty_board.write(current_score)
                                        
                elif len(board) < 5:
                        for i in range(len(board)):
                                board[i] = board[i].split(":")
                        # find index where current score is
                        # less than a leader
                        for i in range(len(board)):
                                # skip if score is greater
                                if int(current_score[1]) > int(board[i][1]):
                                        continue
                        # append index, break loop if score <= current line
                                elif int(current_score[1]) <= \
                                     int(board[i][1]):
                                        index_holder = i
                                        break
                        # failsafe if current score > all available
                        if int(current_score[1]) > int(board[-1][1]):
                                board.append(current_score)
                        elif index_holder >= 0:
                                board.insert(index_holder, current_score)
                        else:
                                pass
                        # need to write new scores back to file
                        with open("smiley_leaders.txt", mode='w') as \
                             new_leads:
                                # del new line characters from last document
                                for each in board:
                                        each = ':'.join(each)
                                # reapply new line character for all
                                # but last index
                                for i in range(len(board)):
                                        if board[i] == board[-1]:
                                                board[i] = ':'.join(board[i])
                                                pass
                                        else:
                                                board[i][2] = board[i][2] \
                                                              + '\n'
                                                board[i] = \
                                                         ':'.join(board[i])
                                for each in board:
                                        new_leads.write(each)
                        leaderboard_update("smiley")
                elif len(board) == 5:
                        for i in range(len(board)):
                                board[i] = board[i].split(":")
                        # find index where current score is less than leader
                        for i in range(len(board)):
                                # skip if score is greater
                                if int(current_score[1]) > int(board[i][1]):
                                        continue
                                # append index, break loop if
                                # score <= current line
                                elif int(current_score[1]) <= \
                                     int(board[i][1]):
                                        index_holder = i
                                        break
                        # failsafe if current score > all available
                        if int(current_score[1]) > int(board[-1][1]):
                                board.append(current_score)
                        elif index_holder >= 0:
                                board.insert(index_holder, current_score)
                        else:
                                pass
                        # del last value before reformatting
                        board.pop()
                        # need to write new scores back to file
                        with open("smiley_leaders.txt", mode='w') as \
                             new_leads:
                                # del new line characters from last document
                                for each in board:
                                        each = ':'.join(each)
                                # reapply new line character for all
                                # but last index
                                for i in range(len(board)):
                                        if board[i] == board[-1]:
                                                board[i] = \
                                                         ':'.join(board[i])
                                                pass
                                        else:
                                                board[i][2] = \
                                                            board[i][2] + \
                                                            '\n'
                                                board[i] = \
                                                         ':'.join(board[i])
                                for each in board:
                                        new_leads.write(each)
                with open("game_status.txt", mode='w') as status:
                        status.write("completed")
                leaderboard_update("smiley")
                with open("visibility.txt", mode='w') as vision:
                        vision.write("visible")
                popup.shape("../final_project_fall_2021/" \
                            "slider_puzzle_project_fall2021_assets/" \
                            "Resources/winner.gif")
                popup.showturtle()
                if check == "completed":
                        pass
        elif score[1] >= score[2] and turtle_tracker != locations:
                with open("visibility.txt", mode='w') as vision:
                        vision.write("visible")
                popup.shape("../final_project_fall_2021/" \
                            "slider_puzzle_project_fall2021_assets/" \
                            "Resources/Lose.gif")
                popup.showturtle()
                
    meta_reader('smiley')
    ts = turtle.Screen()
    turts = turtle.Turtle()
    scorekeep = turtle.Turtle()
    score_present = turtle.Turtle()
    leaders = turtle.Turtle()
    splash = turtle.Turtle()
    popup = turtle.Turtle()
    blank = turtle.Turtle()
    tile_2 = turtle.Turtle()
    tile_3 = turtle.Turtle()
    tile_4 = turtle.Turtle()
    tile_5 = turtle.Turtle()
    tile_6 = turtle.Turtle()
    tile_7 = turtle.Turtle()
    tile_2 = turtle.Turtle()
    tile_8 = turtle.Turtle()
    tile_9 = turtle.Turtle()
    tile_10 = turtle.Turtle()
    tile_11 = turtle.Turtle()
    tile_12 = turtle.Turtle()
    tile_13 = turtle.Turtle()
    tile_14 = turtle.Turtle()
    tile_15 = turtle.Turtle()
    tile_16 = turtle.Turtle()
    blank.hideturtle()
    tile_2.hideturtle()
    tile_3.hideturtle()
    tile_4.hideturtle()
    tile_5.hideturtle()
    tile_6.hideturtle()
    tile_7.hideturtle()
    tile_8.hideturtle()
    tile_9.hideturtle()
    tile_10.hideturtle()
    tile_11.hideturtle()
    tile_12.hideturtle()
    tile_13.hideturtle()
    tile_14.hideturtle()
    tile_15.hideturtle()
    tile_16.hideturtle()
    thumbnail("smiley")
    score_presenter()
    randomizer = random_locations("smiley")
    ts.addshape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "winner.gif")
    ts.addshape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "Lose.gif")
    ts.addshape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "quitmsg.gif")
    ts.addshape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "file_error.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/blank.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/2.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/3.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/4.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/5.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/6.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/7.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/8.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/9.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/10.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/11.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/12.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/13.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/14.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/15.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/16.gif")
    blank.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/blank.gif")
    blank.penup()
    blank.setpos(randomizer[0][0], randomizer[0][1])
    tile_2.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/2.gif")
    tile_2.penup()
    tile_2.setpos(randomizer[1][0], randomizer[1][1])
    tile_3.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/3.gif")
    tile_3.penup()
    tile_3.setpos(randomizer[2][0], randomizer[2][1])
    tile_4.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/4.gif")
    tile_4.penup()
    tile_4.setpos(randomizer[3][0], randomizer[3][1])
    tile_5.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/5.gif")
    tile_5.penup()
    tile_5.setpos(randomizer[4][0], randomizer[4][1])
    tile_6.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/6.gif")
    tile_6.penup()
    tile_6.setpos(randomizer[5][0], randomizer[5][1])
    tile_7.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/7.gif")
    tile_7.penup()
    tile_7.setpos(randomizer[6][0], randomizer[6][1])
    tile_8.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/8.gif")
    tile_8.penup()
    tile_8.setpos(randomizer[7][0], randomizer[7][1])
    tile_9.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/9.gif")
    tile_9.penup()
    tile_9.setpos(randomizer[8][0], randomizer[8][1])
    tile_10.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/10.gif")
    tile_10.penup()
    tile_10.setpos(randomizer[9][0], randomizer[9][1])
    tile_11.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/11.gif")
    tile_11.penup()
    tile_11.setpos(randomizer[10][0], randomizer[10][1])
    tile_12.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/12.gif")
    tile_12.penup()
    tile_12.setpos(randomizer[11][0], randomizer[11][1])
    tile_13.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/13.gif")
    tile_13.penup()
    tile_13.setpos(randomizer[12][0], randomizer[12][1])
    tile_14.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/14.gif")
    tile_14.penup()
    tile_14.setpos(randomizer[13][0], randomizer[13][1])
    tile_15.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/15.gif")
    tile_15.penup()
    tile_15.setpos(randomizer[14][0], randomizer[14][1])
    tile_16.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "smiley/16.gif")
    tile_16.penup()
    tile_16.setpos(randomizer[15][0], randomizer[15][1])
    PositionService.set_position(blank.xcor(), blank.ycor())
    time.sleep(4)
    blank.showturtle()
    tile_2.showturtle()
    tile_3.showturtle()
    tile_4.showturtle()
    tile_5.showturtle()
    tile_6.showturtle()
    tile_7.showturtle()
    tile_8.showturtle()
    tile_9.showturtle()
    tile_10.showturtle()
    tile_11.showturtle()
    tile_12.showturtle()
    tile_13.showturtle()
    tile_14.showturtle()
    tile_15.showturtle()
    tile_16.showturtle()
    #if file missing, write blank version
    if not os.path.exists('smiley_leaders.txt'):
        open('smiley_leaders.txt', mode='w').close()
    with open("game_status.txt", mode='w') as status:
            status.write("ongoing")
    popup.hideturtle()
    with open("visibility.txt", mode='w') as vision:
            vision.write('invisible')
    leaderboard_update("smiley")
    ts.onclick(click_sixteen)

def fifteen_game(username, moves):
    def click_sixteen(x, y):
        turtles = [blank, tile_2, tile_3, tile_4, tile_5, tile_6, tile_7, \
                   tile_8, tile_9, tile_10, tile_11, tile_12, tile_13, \
                   tile_14, tile_15, tile_16]
        vision = visibility_check()
        blank_x = PositionService.get_position_x()
        blank_y = PositionService.get_position_y()
        quit_x = 255
        quit_y = -250
        load_x = 142.5
        load_y = -249.5
        reset_x = 50
        reset_y = -250
        if vision == True:
                if x <= 400 and x >= -400 and y <= 400 and y >= -400:
                        popup.hideturtle()
                        with open("visibility.txt", mode='w') as vision:
                                vision.write('invisible')
        else:
                # Quit button
                if x >= (quit_x - 60) and x <= (quit_x + 60) \
                   and y >= (quit_y - 25) and y <= (quit_y + 25):
                    with open("visibility.txt", mode='w') as vision:
                            vision.write("visible")
                    with open("game_status.txt", mode='w') as status:
                        status.write("ongoing")
                    popup.shape("../final_project_fall_2021/" \
                                "slider_puzzle_project_fall2021_assets/" \
                                "Resources/quitmsg.gif")
                    popup.showturtle()
                    time.sleep(5)
                    turtle.bye()
                # Load button
                elif x >= (load_x - 37.5) and x <= (load_x + 37.5) \
                   and y >= (load_y - 37.5) and y <= (load_y + 37.5):
                    with open("visibility.txt", mode='w') as vision:
                            vision.write("invisible")
                    with open("game_status.txt", mode='w') as status:
                            status.write("completed")
                    new_puzzle = ts.textinput("5001 Puzzle Slide - Load", \
                                              "Which puzzle would you" \
                                              " like to switch" \
                                              " to?\nOptions:\nMario\n" \
                                              "Luigi\nYoshi\nSmiley\n" \
                                              "Fifteen")
                    new_puzzle = new_puzzle.lower()
                    puzzle_validation(new_puzzle)
                    turts.hideturtle()
                    # Hide all relevant turtles, clear board
                    for each in turtles:
                        each.hideturtle()
                    # Choose new game, location and controls
                    game_picker(new_puzzle, username, moves)
                    with open("scorekeeper.txt", mode='w') as new_score:
                        current_score = [f'{username}', '0', f'{moves}']
                        current_score = ":".join(current_score)
                        new_score.write(current_score)
                    score_presenter()
                # Reset button
                elif x >= (reset_x - 40) and x <= (reset_x + 40) \
                   and y >= (reset_y - 40) and y <= (reset_y + 40):
                    with open("game_status.txt", mode='w') as status:
                            status.write("completed")
                    locations = [[-3, -72], [-101, -72], [-199, -72], \
                                 [-297, -72], [-3, 26], [-101, 26], \
                                 [-199, 26], [-297, 26], [-3, 124], \
                                 [-101, 124], [-199, 124], [-297, 124], \
                                 [-3, 222], [-101, 222], [-199, 222], \
                                 [-297, 222]]
                    score = 0
                    blank.setpos(locations[0][0], locations[0][1])
                    PositionService.set_position(locations[0][0], \
                                                 locations[0][1])
                    tile_2.setpos(locations[1][0], locations[1][1])
                    tile_3.setpos(locations[2][0], locations[2][1])
                    tile_4.setpos(locations[3][0], locations[3][1])
                    tile_5.setpos(locations[4][0], locations[4][1])
                    tile_6.setpos(locations[5][0], locations[5][1])
                    tile_7.setpos(locations[6][0], locations[6][1])
                    tile_8.setpos(locations[7][0], locations[7][1])
                    tile_9.setpos(locations[8][0], locations[8][1])
                    tile_10.setpos(locations[9][0], locations[9][1])
                    tile_11.setpos(locations[10][0], locations[10][1])
                    tile_12.setpos(locations[11][0], locations[11][1])
                    tile_13.setpos(locations[12][0], locations[12][1])
                    tile_14.setpos(locations[13][0], locations[13][1])
                    tile_15.setpos(locations[14][0], locations[14][1])
                    tile_16.setpos(locations[15][0], locations[15][1])
                    score_check()
                # Bottom Right White Tile
                elif blank_x == -3 and blank_y == -72:
                    # Go Bot Left
                    if x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-101, -72): 
                                each.setpos(-3, -72)
                                blank.setpos(-101, -72)
                                PositionService.set_position(-101, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Right
                    elif x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48): 
                        for each in turtles:
                            if each.pos() == (-3, 26):
                                each.setpos(-3, -72)
                                blank.setpos(-3, 26)
                                PositionService.set_position(-3, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Mid Bot Right White Tile
                elif blank_x == -101 and blank_y == -72:
                    # Go Bot Right 1/3
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-3, -72):
                                each.setpos(-101, -72)
                                blank.setpos(-3, -72)
                                PositionService.set_position(-3, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Middle 2/3
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 26):
                                each.setpos(-101, -72)
                                blank.setpos(-101, 26)
                                PositionService.set_position(-101, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Bot Left 3/3
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-199, -72):
                                each.setpos(-101, -72)
                                blank.setpos(-199, -72)
                                PositionService.set_position(-199, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Mid Bot Left White Tile
                elif blank_x == -199 and blank_y == -72:
                    # Go Bot Mid
                    if x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-101, -72):
                                each.setpos(-199, -72)
                                blank.setpos(-101, -72)
                                PositionService.set_position(-101, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Low Mid Left
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 26):
                                each.setpos(-199, -72)
                                blank.setpos(-199, 26)
                                PositionService.set_position(-199, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Low Mid Left
                    elif x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-297, -72):
                                each.setpos(-199, -72)
                                blank.setpos(-297, -72)
                                PositionService.set_position(-297, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Bot Left White Tile
                elif blank_x == -297 and blank_y == -72:
                    # Go Bot Left Mid
                    if x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-199, -72):
                                each.setpos(-297, -72)
                                blank.setpos(-199, -72)
                                PositionService.set_position(-199, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Mid Left
                    elif x <= (-297 + 48) and x >= (-297 -48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 26):
                                each.setpos(-297, -72)
                                blank.setpos(-297, 26)
                                PositionService.set_position(-297, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Middle Right White Tile
                elif blank_x == -3 and blank_y == 26:
                    # Go Bot Right 1/3
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-3, -72):
                                each.setpos(-3, 26)
                                blank.setpos(-3, -72)
                                PositionService.set_position(-3, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Middle 2/3
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 26):
                                each.setpos(-3, 26)
                                blank.setpos(-101, 26)
                                PositionService.set_position(-101, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Right 3/3
                    elif x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 124):
                                each.setpos(-3, 26)
                                blank.setpos(-3, 124)
                                PositionService.set_position(-3, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Center White Tile
                elif blank_x == -101 and blank_y == 26:
                    # Go Mid Right 1/4
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 26):
                                each.setpos(-101, 26)
                                blank.setpos(-3, 26)
                                PositionService.set_position(-3, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Bot Mid 2/4
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-101, -72): 
                                each.setpos(-101, 26)
                                blank.setpos(-101, -72)
                                PositionService.set_position(-101, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Mid Left 3/4
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 26): 
                                each.setpos(-101, 26)
                                blank.setpos(-199, 26)
                                PositionService.set_position(-199, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Mid 4/4
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 124): 
                                each.setpos(-101, 26)
                                blank.setpos(-101, 124)
                                PositionService.set_position(-101, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Middle Left White Tile
                elif blank_x == -199 and blank_y == 26:
                    # Go Bot Left 1/3
                    if x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-199, -72):
                                each.setpos(-199, 26)
                                blank.setpos(-199, -72)
                                PositionService.set_position(-199, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Middle 2/3
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 26):
                                each.setpos(-199, 26)
                                blank.setpos(-101, 26)
                                PositionService.set_position(-101, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Middle 2/3
                    elif x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 26):
                                each.setpos(-199, 26)
                                blank.setpos(-297, 26)
                                PositionService.set_position(-297, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Left 3/3
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 124):
                                each.setpos(-199, 26)
                                blank.setpos(-199, 124)
                                PositionService.set_position(-199, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Middle Left White Tile
                elif blank_x == -297 and blank_y == 26:
                    # Go Upper Left 1/3
                    if x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 124):
                                each.setpos(-297, 26)
                                blank.setpos(-297, 124)
                                PositionService.set_position(-297, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Bot Left 2/3
                    elif x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (-72 + 48) and y >= (-72 - 48):
                        for each in turtles:
                            if each.pos() == (-297, -72):
                                each.setpos(-297, 26)
                                blank.setpos(-297, -72)
                                PositionService.set_position(-297, -72)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                    # Go Bot Middle 3/3
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 26):
                                each.setpos(-297, 26)
                                blank.setpos(-199, 26)
                                PositionService.set_position(-199, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Mid Top Right White Tile
                elif blank_x == -3 and blank_y == 124:
                    # Go Lower Mid Right 1/3
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 26):
                                each.setpos(-3, 124)
                                blank.setpos(-3, 26)
                                PositionService.set_position(-3, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Upper Mid R 2/3
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 124):
                                each.setpos(-3, 124)
                                blank.setpos(-101, 124)
                                PositionService.set_position(-101, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Right C 1/3
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 222):
                                each.setpos(-3, 124)
                                blank.setpos(-3, 222)
                                PositionService.set_position(-3, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Upper Mid R White Tile
                elif blank_x == -101 and blank_y == 124:
                    # Go Top Right M 1/4
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 124):
                                each.setpos(-101, 124)
                                blank.setpos(-3, 124)
                                PositionService.set_position(-3, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Low Mid Left 2/4
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 26):
                                each.setpos(-101, 124)
                                blank.setpos(-101, 26)
                                PositionService.set_position(-101, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Upper Mid Left 3/4
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 124):
                                each.setpos(-101, 124)
                                blank.setpos(-199, 124)
                                PositionService.set_position(-199, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Upper Mid Left 3/4
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 222):
                                each.setpos(-101, 124)
                                blank.setpos(-101, 222)
                                PositionService.set_position(-101, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Upper Center left White Tile
                elif blank_x == -199 and blank_y == 124:
                    # Go Mid Left 1/4
                    if x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48): 
                        for each in turtles:
                            if each.pos() == (-199, 26):
                                each.setpos(-199, 124)
                                blank.setpos(-199, 26)
                                PositionService.set_position(-199, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Bot Center 2/4
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48): 
                        for each in turtles:
                            if each.pos() == (-101, 124):
                                each.setpos(-199, 124)
                                blank.setpos(-101, 124)
                                PositionService.set_position(-101, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Middle L 3/4
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48): 
                        for each in turtles:
                            if each.pos() == (-199, 222):
                                each.setpos(-199, 124)
                                blank.setpos(-199, 222)
                                PositionService.set_position(-199, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Upper L 4/4
                    elif x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 124):
                                each.setpos(-199, 124)
                                blank.setpos(-297, 124)
                                PositionService.set_position(-297, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Top Left Side White Tile
                elif blank_x == -297 and blank_y == 124:
                    # Go Low Left Side 1/3
                    if x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (26 + 48) and y >= (26 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 26):
                                each.setpos(-297, 124)
                                blank.setpos(-297, 26)
                                PositionService.set_position(-297, 26)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Up Left Center 2/3
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 124):
                                each.setpos(-297, 124)
                                blank.setpos(-199, 124)
                                PositionService.set_position(-199, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top Left Corner 2/3
                    elif x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 222):
                                each.setpos(-297, 124)
                                blank.setpos(-297, 222)
                                PositionService.set_position(-297, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Top Right Corner White Tile
                elif blank_x == -3 and blank_y == 222:
                    # Go Low Left Side 1/2
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 124):
                                each.setpos(-3, 222)
                                blank.setpos(-3, 124)
                                PositionService.set_position(-3, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Up Left Center 2/2
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 222):
                                each.setpos(-3, 222)
                                blank.setpos(-101, 222)
                                PositionService.set_position(-101, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Top Right Mid White Tile
                elif blank_x == -101 and blank_y == 222:
                    # Go Top Right Corn 1/3
                    if x <= (-3 + 48) and x >= (-3 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-3, 222):
                                each.setpos(-101, 222)
                                blank.setpos(-3, 222)
                                PositionService.set_position(-3, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Upper R Center 2/3
                    elif x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 124):
                                each.setpos(-101, 222)
                                blank.setpos(-101, 124)
                                PositionService.set_position(-101, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top L Center 3/3
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 222):
                                each.setpos(-101, 222)
                                blank.setpos(-199, 222)
                                PositionService.set_position(-199, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Top Left Mid White Tile
                elif blank_x == -199 and blank_y == 222:
                    # Go Top Right Cent 1/3
                    if x <= (-101 + 48) and x >= (-101 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-101, 222):
                                each.setpos(-199, 222)
                                blank.setpos(-101, 222)
                                PositionService.set_position(-101, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Upper R Center 2/3
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 124):
                                each.setpos(-199, 222)
                                blank.setpos(-199, 124)
                                PositionService.set_position(-199, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top L Center 3/3
                    elif x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 222):
                                each.setpos(-199, 222)
                                blank.setpos(-297, 222)
                                PositionService.set_position(-297, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                # Top Left Corner
                elif blank_x == -297 and blank_y == 222:
                    # Go Upper Left Side 1/2
                    if x <= (-297 + 48) and x >= (-297 - 48) \
                       and y <= (124 + 48) and y >= (124 - 48):
                        for each in turtles:
                            if each.pos() == (-297, 124):
                                each.setpos(-297, 222)
                                blank.setpos(-297, 124)
                                PositionService.set_position(-297, 124)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()
                    # Go Top L Center 2/2
                    elif x <= (-199 + 48) and x >= (-199 - 48) \
                       and y <= (222 + 48) and y >= (222 - 48):
                        for each in turtles:
                            if each.pos() == (-199, 222):
                                each.setpos(-297, 222)
                                blank.setpos(-199, 222)
                                PositionService.set_position(-199, 222)
                        with open("scorekeeper.txt", mode='r') as scoreboard:
                            current_score = scoreboard.readline()
                            current_score = current_score.split(":")
                        with open("scorekeeper.txt", mode='w') as new_score:
                            current_score[1] = int(current_score[1])
                            current_score[1] += 1
                            current_score[1] = str(current_score[1])
                            current_score = ":".join(current_score)
                            new_score.write(current_score)
                        score_presenter()
                        score_check()

    def thumbnail(image: str):
        screen = turtle.getscreen()
        turts.penup()
        turts.hideturtle()
        turts.setposition(290, 260)
        pic = "../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              f"{image}/{image}_thumbnail.gif"
        screen.addshape(pic)
        turts.shape(pic)
        turts.showturtle()
        
    def leaderboard_update(game_name):
        style = ('Calibri', 24, 'bold')
        with open(f"{game_name}_leaders.txt", mode='r') as leaderboard:
                board = leaderboard.readlines()
                for i in range(len(board)):
                        board[i] = board[i].replace("\n", "")
                        board[i] = board[i].split(':')
        leaders.pencolor("#350A0A")
        leaders.speed(0)
        leaders.penup()
        leaders.hideturtle()
        leaders.setpos(110, 210)
        leaders.fillcolor("beige")
        leaders.begin_fill()
        leaders.setheading(270)
        leaders.forward(300)
        leaders.left(90)
        leaders.forward(150)
        leaders.left(90)
        leaders.forward(300)
        leaders.left(90)
        leaders.forward(150)
        leaders.left(90)
        leaders.end_fill()
        leaders.setpos(110, 160)
        for i in range(len(board)):
                score = f"{board[i][1]}: {board[i][0]}"
                leaders.write(score, font=style, align='left')
                leaders.forward(60)
                
    def score_presenter():
        score_present.speed(0)
        score_present.hideturtle()
        score_present.penup()
        score_present.setpos(-188, -267)
        score_present.fillcolor('beige')
        score_present.begin_fill()
        score_present.forward(100)
        score_present.left(90)
        score_present.forward(50)
        score_present.left(90)
        score_present.forward(103)
        score_present.left(90)
        score_present.forward(50)
        score_present.left(90)
        score_present.forward(3)
        score_present.end_fill()
        score_present.pencolor("#350A0A")
        style = ('Calibri', 26, 'bold')
        with open("scorekeeper.txt", mode='r') as score:
            scorer = score.readline()
            scores = scorer.split(":")
            score_present.write(f"{scores[1]}", font=style, align='left')
            
    def score_check():
        turtles = [blank, tile_2, tile_3, tile_4, tile_5, tile_6, tile_7, \
                   tile_8, tile_9, tile_10, tile_11, tile_12, tile_13, \
                   tile_14, tile_15, tile_16]
        locations = [[-3, -72], [-101, -72], [-199, -72], [-297, -72], \
                     [-3, 26], [-101, 26], [-199, 26], [-297, 26], \
                     [-3, 124], [-101, 124], [-199, 124], [-297, 124], \
                     [-3, 222], [-101, 222], [-199, 222], [-297, 222]]
        turtle_tracker = []
        for each in turtles:
            turtle_tracker.append(list(each.pos()))
        with open("scorekeeper.txt", mode="r") as scoreboard:
            current_score = scoreboard.readline()
            score = current_score.split(":")
            score[1] = int(score[1])
            score[2] = int(score[2])
            # If the score is less or equal to limit and locations
            # match solved
        if score[1] <= score[2] and turtle_tracker == locations:
            with open("game_status.txt") as status:
                    check = status.readline()
            if check == "ongoing":
                # making the current score a variable
                with open("scorekeeper.txt", mode='r') as \
                     scoreboard:
                        current_score = scoreboard.readline()
                        current_score = current_score.split(":")
                board = []
                # adds all logged scores to board list
                with open("fifteen_leaders.txt", mode='r') \
                     as leaderboard:
                        board = leaderboard.readlines()
                for i in range(len(board)):
                        board[i] = board[i].replace("\n", "")
                if len(board) == 0:
                        with open("fifteen_leaders.txt", mode='w') \
                                as empty_board:
                                current_score = ':'.join(current_score)
                                empty_board.write(current_score)
                                        
                elif len(board) < 5:
                        for i in range(len(board)):
                                board[i] = board[i].split(":")
                        # find index where current score is
                        # less than a leader
                        for i in range(len(board)):
                                # skip if score is greater
                                if int(current_score[1]) > int(board[i][1]):
                                        continue
                        # append index, break loop if score <= current line
                                elif int(current_score[1]) <= \
                                     int(board[i][1]):
                                        index_holder = i
                                        break
                        # failsafe if current score > all available
                        if int(current_score[1]) > int(board[-1][1]):
                                board.append(current_score)
                        elif index_holder >= 0:
                                board.insert(index_holder, current_score)
                        else:
                                pass
                        # need to write new scores back to file
                        with open("fifteen_leaders.txt", mode='w') as \
                             new_leads:
                                # del new line characters from last document
                                for each in board:
                                        each = ':'.join(each)
                                # reapply new line character for all
                                # but last index
                                for i in range(len(board)):
                                        if board[i] == board[-1]:
                                                board[i] = ':'.join(board[i])
                                                pass
                                        else:
                                                board[i][2] = board[i][2] \
                                                              + '\n'
                                                board[i] = \
                                                         ':'.join(board[i])
                                for each in board:
                                        new_leads.write(each)
                        leaderboard_update("fifteen")
                elif len(board) == 5:
                        for i in range(len(board)):
                                board[i] = board[i].split(":")
                        # find index where current score is less than leader
                        for i in range(len(board)):
                                # skip if score is greater
                                if int(current_score[1]) > int(board[i][1]):
                                        continue
                                # append index, break loop if
                                # score <= current line
                                elif int(current_score[1]) <= \
                                     int(board[i][1]):
                                        index_holder = i
                                        break
                        # failsafe if current score > all available
                        if int(current_score[1]) > int(board[-1][1]):
                                board.append(current_score)
                        elif index_holder >= 0:
                                board.insert(index_holder, current_score)
                        else:
                                pass
                        # del last value before reformatting
                        board.pop()
                        # need to write new scores back to file
                        with open("fifteen_leaders.txt", mode='w') as \
                             new_leads:
                                # del new line characters from last document
                                for each in board:
                                        each = ':'.join(each)
                                # reapply new line character for all
                                # but last index
                                for i in range(len(board)):
                                        if board[i] == board[-1]:
                                                board[i] = \
                                                         ':'.join(board[i])
                                                pass
                                        else:
                                                board[i][2] = \
                                                            board[i][2] + \
                                                            '\n'
                                                board[i] = \
                                                         ':'.join(board[i])
                                for each in board:
                                        new_leads.write(each)
                with open("game_status.txt", mode='w') as status:
                        status.write("completed")
                leaderboard_update("fifteen")
                with open("visibility.txt", mode='w') as vision:
                        vision.write("visible")
                popup.shape("../final_project_fall_2021/" \
                            "slider_puzzle_project_fall2021_assets/" \
                            "Resources/winner.gif")
                popup.showturtle()
                if check == "completed":
                        pass
        elif score[1] >= score[2] and turtle_tracker != locations:
                with open("visibility.txt", mode='w') as vision:
                        vision.write("visible")
                popup.shape("../final_project_fall_2021/" \
                            "slider_puzzle_project_fall2021_assets/" \
                            "Resources/Lose.gif")
                popup.showturtle()
                
    meta_reader('fifteen')   
    ts = turtle.Screen()
    turts = turtle.Turtle()
    scorekeep = turtle.Turtle()
    score_present = turtle.Turtle()
    leaders = turtle.Turtle()
    splash = turtle.Turtle()
    popup = turtle.Turtle()
    blank = turtle.Turtle()
    tile_2 = turtle.Turtle()
    tile_3 = turtle.Turtle()
    tile_4 = turtle.Turtle()
    tile_5 = turtle.Turtle()
    tile_6 = turtle.Turtle()
    tile_7 = turtle.Turtle()
    tile_2 = turtle.Turtle()
    tile_8 = turtle.Turtle()
    tile_9 = turtle.Turtle()
    tile_10 = turtle.Turtle()
    tile_11 = turtle.Turtle()
    tile_12 = turtle.Turtle()
    tile_13 = turtle.Turtle()
    tile_14 = turtle.Turtle()
    tile_15 = turtle.Turtle()
    tile_16 = turtle.Turtle()
    blank.hideturtle()
    tile_2.hideturtle()
    tile_3.hideturtle()
    tile_4.hideturtle()
    tile_5.hideturtle()
    tile_6.hideturtle()
    tile_7.hideturtle()
    tile_8.hideturtle()
    tile_9.hideturtle()
    tile_10.hideturtle()
    tile_11.hideturtle()
    tile_12.hideturtle()
    tile_13.hideturtle()
    tile_14.hideturtle()
    tile_15.hideturtle()
    tile_16.hideturtle()
    thumbnail("fifteen")
    score_presenter()
    randomizer = random_locations("smiley")
    ts.addshape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "winner.gif")
    ts.addshape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "Lose.gif")
    ts.addshape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "quitmsg.gif")
    ts.addshape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "file_error.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/blank.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/2.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/3.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/4.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/5.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/6.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/7.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/8.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/9.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/10.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/11.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/12.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/13.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/14.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/15.gif")
    ts.addshape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/16.gif")
    blank.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/blank.gif")
    blank.penup()
    blank.setpos(randomizer[0][0], randomizer[0][1])
    tile_2.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/2.gif")
    tile_2.penup()
    tile_2.setpos(randomizer[1][0], randomizer[1][1])
    tile_3.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/3.gif")
    tile_3.penup()
    tile_3.setpos(randomizer[2][0], randomizer[2][1])
    tile_4.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/4.gif")
    tile_4.penup()
    tile_4.setpos(randomizer[3][0], randomizer[3][1])
    tile_5.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/5.gif")
    tile_5.penup()
    tile_5.setpos(randomizer[4][0], randomizer[4][1])
    tile_6.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/6.gif")
    tile_6.penup()
    tile_6.setpos(randomizer[5][0], randomizer[5][1])
    tile_7.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/7.gif")
    tile_7.penup()
    tile_7.setpos(randomizer[6][0], randomizer[6][1])
    tile_8.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/8.gif")
    tile_8.penup()
    tile_8.setpos(randomizer[7][0], randomizer[7][1])
    tile_9.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/9.gif")
    tile_9.penup()
    tile_9.setpos(randomizer[8][0], randomizer[8][1])
    tile_10.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/10.gif")
    tile_10.penup()
    tile_10.setpos(randomizer[9][0], randomizer[9][1])
    tile_11.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/11.gif")
    tile_11.penup()
    tile_11.setpos(randomizer[10][0], randomizer[10][1])
    tile_12.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/12.gif")
    tile_12.penup()
    tile_12.setpos(randomizer[11][0], randomizer[11][1])
    tile_13.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/13.gif")
    tile_13.penup()
    tile_13.setpos(randomizer[12][0], randomizer[12][1])
    tile_14.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/14.gif")
    tile_14.penup()
    tile_14.setpos(randomizer[13][0], randomizer[13][1])
    tile_15.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/15.gif")
    tile_15.penup()
    tile_15.setpos(randomizer[14][0], randomizer[14][1])
    tile_16.shape("../final_project_fall_2021/" \
              "slider_puzzle_project_fall2021_assets/Images/" \
              "fifteen/16.gif")
    tile_16.penup()
    tile_16.setpos(randomizer[15][0], randomizer[15][1])
    PositionService.set_position(blank.xcor(), blank.ycor())
    time.sleep(4)
    blank.showturtle()
    tile_2.showturtle()
    tile_3.showturtle()
    tile_4.showturtle()
    tile_5.showturtle()
    tile_6.showturtle()
    tile_7.showturtle()
    tile_8.showturtle()
    tile_9.showturtle()
    tile_10.showturtle()
    tile_11.showturtle()
    tile_12.showturtle()
    tile_13.showturtle()
    tile_14.showturtle()
    tile_15.showturtle()
    tile_16.showturtle()
    #if file missing, write blank version
    if not os.path.exists('fifteen_leaders.txt'):
        open('fifteen_leaders.txt', mode='w').close()
    with open("game_status.txt", mode='w') as status:
            status.write("ongoing")
    popup.hideturtle()
    with open("visibility.txt", mode='w') as vision:
            vision.write('invisible')
    leaderboard_update("fifteen")
    ts.onclick(click_sixteen)
    

        
def game_start():
    ts = turtle.Screen()
    splash = turtle.Turtle()
    splash.hideturtle()
    ts.addshape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "splash_screen.gif")
    username = ts.textinput("CS 5001 Puzzle Slide", "Your name:")
    moves = int(ts.numinput("5001 Puzzle Slide - Moves", "Enter the "\
                         "number of moves (chances) you want:", \
                        minval=5, maxval=200))
    score = 0
    splash.shape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "splash_screen.gif")
    splash.showturtle()
    time.sleep(8)
    splash.hideturtle()
    outline()
    with open("scorekeeper.txt", mode='w') as scoreboard:
        scoreboard.write(f"{username}:{score}:{moves}")
    yoshi_game(username, moves)
def main():
    game_start()
if __name__ == "__main__":
    main()
