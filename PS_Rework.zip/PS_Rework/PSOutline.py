import turtle

'''
This function creates the entire background of the Puzzle Slider Interface.
'''
def outline():
    
    # canvas drawing turtle and screen
    turt = turtle.Turtle()
    turt.hideturtle()
    screen = turtle.Screen()

    '''
    This function draws a square given the requested square's length and height.
    '''
    def square(length, height):
        turt.speed(0)
        turt.setheading(0)
        turt.pendown()
        turt.forward(length)
        turt.right(90)
        turt.forward(height)
        turt.right(90)
        turt.forward(length)
        turt.right(90)
        turt.forward(height)
        turt.penup()

    '''
    This sub function creates the top left interface window, used for tiles.
    '''
    def game_window():
        turt.pensize(8)
        turt.hideturtle()
        turt.penup()
        turt.pencolor("#350A0A")
        turt.fillcolor("beige")
        turt.setposition(-350, 300) # Top left of left frame
        turt.begin_fill()
        square(401, 450)
        turt.end_fill()

    '''
    This sub function creates the leaderboard frame.
    '''
    def leaderboard_frame():
        # Top left of right frame
        turt.setposition(100, 300) 
        turt.begin_fill()
        square(225, 450)
        turt.end_fill()
        turt.setposition(100, 300)
        turt.setheading(270)
        turt.forward(40)
        turt.setheading(0)
        turt.forward(10)
        x = turt.xcor()
        y = turt.ycor()
        style = ('Calibri', 28, 'bold')
        turt.write('Leaders:', font=style, align='left')
        turt.setheading(270)
        turt.forward(3)
        turt.setheading(0)
        turt.pensize(6)
        turt.pendown()
        turt.forward(108)
        turt.penup()

    '''
    This sub function creates the scoreboard frame.
    '''
    def score_frame():
        # Top left of bottom frame
        turt.setposition(-350, -200) 
        turt.begin_fill()
        square(675, 100)
        turt.end_fill()

    '''
    This sub function creates the scoreboard outline.
    '''
    def name_present():
        name_present = turtle.Turtle()
        name_present.speed(0)
        name_present.penup()
        name_present.hideturtle()
        name_present.setpos(-330, -265)
        name_present.pencolor("#350A0A")
        style = ('Calibri', 26, 'bold')
        name_present.write("User score: ", font=style, align='left')
        name_present.setheading(270)
        name_present.forward(2)
        name_present.setheading(0)
        name_present.pendown()
        name_present.pensize(5)
        name_present.forward(133)
        name_present.penup()

    '''
    This sub function creates the quit symbol.
    '''
    def quit_symbol():
        turt.hideturtle()
        turt.setposition(195, -225) # Top of square
        turt.pensize(4)
        turt.fillcolor("#350A0A")
        turt.begin_fill()
        square(120, 50)
        turt.end_fill()
        turt.right(90)
        turt.forward(60)
        turt.right(90)
        turt.forward(42) # Center location for text
        turt.color("beige")
        style = ('Calibri', 28, 'bold')
        turt.write("Q U I T", font=style, align='center')

    '''
    This sub function creates the load symbol.
    '''
    def load_symbol():
        turt.setposition(105, -212)
        turt.pensize(6)
        turt.pencolor("#350A0A")
        square(75, 75)
        turt.right(180)
        turt.forward(45)
        turt.left(90)
        turt.forward(10)
        turt.pensize(3)
        square(55, 10) # Empty load bar square
        turt.right(180)
        turt.forward(25)
        turt.left(90)
        turt.forward(15)
        style = ('Calibri', 10, 'normal')
        turt.write("LOAD", font=style, align='left') # LOAD text
        turt.setheading(90)
        turt.forward(15.5)
        turt.right(90)
        turt.forward(35)
        turt.fillcolor("#350A0A")
        turt.begin_fill()
        turt.circle(4) # Circle in load bar
        turt.end_fill()
        turt.right(180)
        turt.forward(32)
        turt.right(90)
        turt.forward(35.5)
        turt.begin_fill()
        square(15, 20) # Bottom of arrow
        turt.end_fill()
        turt.left(180)
        turt.pendown()
        turt.forward(10)
        turt.right(90)
        turt.forward(10)
        turt.right(180)
        turt.begin_fill() # Left side of arrow
        turt.forward(17.5)
        turt.left(90)
        turt.forward(20)
        turt.right(220)
        turt.forward(26.57)
        turt.end_fill()
        turt.setheading(0)
        turt.forward(35)
        turt.right(180)
        turt.begin_fill() # Right side of arrow
        turt.forward(17.5)
        turt.right(90)
        turt.forward(20)
        turt.left(222)
        turt.forward(26.57)
        turt.end_fill()

    '''
    This sub function creates the reset symbol.
    '''
    def reset_symbol():
        turt.penup()
        turt.setposition(0,0)
        turt.setheading(270)
        turt.forward(250)
        turt.setheading(0)
        turt.forward(10)
        turt.setheading(270)
        turt.pendown()
        turt.pensize(6)
        turt.circle(40, steps=64) # Reset button border
        turt.penup()
        turt.left(90)
        turt.forward(40)
        center_x = turt.xcor() # x and y coordinate of center of circle
        center_y = turt.ycor()
        turtle.forward(5)
        turt.right(90)
        turt.forward(10) # Move to center, bring reset word down 10 pixels
        style = ('Calibri', 14, 'bold')
        turt.write('RESET', font=style, align='center')
        turt.setheading(90)
        turt.forward(40)
        turt.setheading(180)
        turt.forward(2)
        turt.pensize(1)
        x = turt.xcor() # x and y coordinate of top of arrow semicircle
        y = turt.ycor()
        turt.begin_fill()
        turt.pendown()
        turt.setheading(180)
        turt.circle(30, extent=-50)
        turt.right(90)
        turt.forward(5)
        turt.right(135)
        turt.forward(11.18)
        turt.right(90)
        turt.forward(11.18)
        turt.right(135)
        turt.forward(5)
        turt.left(90)
        turt.circle(28, extent=45)
        turt.end_fill()
        turt.penup()
        turt.setposition(x,y)
        turt.pendown()
        turt.begin_fill()
        turt.setheading(180)
        turt.circle(30, extent=60)
        turt.left(90)
        turt.forward(5.5)
        turt.left(90)
        turt.setheading(-125)
        turt.circle(28, extent=-54)
        turt.penup()
        turt.end_fill() # End of top arrow
        turt.setposition(center_x, center_y)
        turt.setheading(270)
        turt.forward(30)
        x = turt.xcor() # x and y coordinate of bottom of arrow semicircle
        y = turt.ycor()
        turt.begin_fill()
        turt.pendown()
        turt.setheading(0)
        turt.circle(30, extent=-50)
        turt.right(90)
        turt.forward(5)
        turt.right(135)
        turt.forward(11.18)
        turt.right(90)
        turt.forward(11.18)
        turt.right(135)
        turt.forward(5)
        turt.left(90)
        turt.circle(28, extent=45)
        turt.end_fill()
        turt.penup()
        turt.setposition(x, y)
        turt.pendown()
        turt.begin_fill()
        turt.setheading(0)
        turt.circle(30, extent=60)
        turt.left(90)
        turt.forward(5.5)
        turt.left(90)
        turt.setheading(55)
        turt.circle(28, extent=-54)
        turt.penup()
        turt.end_fill() # End of bottom arrow
        
    turtle.hideturtle()
    screen.bgcolor("#DFF9FF")
    turt.pensize(8)
    turt.hideturtle()
    turt.penup()
    turt.pencolor("#350A0A")
    turt.fillcolor("beige")
    game_window()
    leaderboard_frame()
    score_frame()
    quit_symbol()
    load_symbol()
    reset_symbol()
    name_present()
    turt.hideturtle()
    turtle.hideturtle()
