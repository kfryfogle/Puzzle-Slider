'''
Utility Functions
'''

import os.path
from PSTile import Tile
import random

'''
Randomizes locations based on the requested puzzle
'''
def random_locations(game_name):
    rand_places = []
    if game_name.lower() == "yoshi":
        locations = [[-101, 26], [-199, 26], [-101, 124], [-199, 124]]
        correct = [0, 1, 2, 3]
        shuffled = [0, 1, 2, 3]
        # shuffle the index numbers until they aren't in correct order
        while(correct == shuffled):
            random.shuffle(shuffled)
        # give each random place index a value based off shuffled index
        for i in shuffled:
            rand_places.append(locations[i])
        return rand_places
    
    elif game_name.lower() == "luigi":
        locations = [[-51.5, -23], [-149.5, -23], [-247.5, -23], \
                          [-51.5, 75], [-149.5, 75], [-247.5, 75], \
                          [-51.5, 173], [-149.5, 173], [-247.5, 173]]
        correct = [0, 1, 2, 3, 4, 5, 6, 7, 8]
        shuffled = [0, 1, 2, 3, 4, 5, 6, 7, 8]
        # shuffle the index numbers until they aren't in correct order
        while(correct == shuffled):
            random.shuffle(shuffled)
        # give each random place index a value based off shuffled index
        for i in shuffled:
            rand_places.append(locations[i])
        return rand_places
    
    elif game_name.lower() == "mario" or game_name.lower() == "smiley" or \
         game_name.lower() == 'fifteen':
        locations = [[-3, -72], [-101, -72], [-199, -72], [-297, -72], \
                 [-3, 26], [-101, 26], [-199, 26], [-297, 26], [-3, 124], \
                 [-101, 124], [-199, 124], [-297, 124], [-3, 222], \
                 [-101, 222], [-199, 222], [-297, 222]]
        correct = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
        shuffled = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
        # shuffle the index numbers until they aren't in correct order
        while(correct == shuffled):
            random.shuffle(shuffled)
        # give each random place index a value based off shuffled index
        for i in shuffled:
            rand_places.append(locations[i])
        return rand_places

'''
Function returns a boolean true if both lists input are placed in the same order
'''
def list_symmetry(l1, l2):
    same = True
    size = len(l1)
    size2 = len(l2)
    for i in range(0, size):
        # if each coordinate in same order return true
        if (l1[i][0] == l2[i][0] and l1[i][1] == l2[i][1]):
            same = True
        else:
            same = False
            return same
    return same
    
'''
Create a list of all the tiles in the game
'''
def tile_list():
    tiles = []
    # create 15 new tiles total
    for i in range(0, 16):
        newTile = Tile()
        # append tiles to the list
        tiles.append(newTile)
    # return the list
    return tiles

'''
Checks the metadata file for each game based on formatting
'''
def meta_reader(filename):
    # correct length of total lines in each games data file
    yoshi_fl_len = 8
    luigi_fl_len = 13
    fifteen_fl_len = 20
    
    # make error directory if not already available
    if not os.path.exists("./error_log/"):
        os.makedirs("./error_log/")
        
    # make error file if not already available
    if not os.path.exists("./error_log/5001_puzz.err"):
        open('./error_log/5001_puzz.err', mode='w').close()
        
    # open error log and check requested game file data
    with open('./error_log/5001_puzz.err', mode='a') as errors:
        # yoshi filechecker
        if filename == "yoshi":
            with open("./slider_puzzle_project_fall2021_assets/" \
                      "yoshi.puz") as file:
                lines = file.readlines()
            for i in range(len(lines)):
                lines[i] = lines[i].replace('\n', '')
            # check total file line length
            if len(lines) != yoshi_fl_len:
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Value Error: Not enough metadata info"  \
                             + '\n')
                raise ValueError
            if lines[0] != "name: yoshi":
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("incorrect name in yoshi metadata" + '\n')
                raise OSError
            # number line
            lines[1] = lines[1].replace('number: ', '')
            if int(lines[1]) != 4:
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Value Error: Incorrect Puzzle Size" + '\n')
                raise ValueError
            # size line
            lines[2] = lines[2].replace('size: ', '')
            if int(lines[2]) < 50 or int(lines[2]) > 110:
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Value Error: Incorrect Image Size" + '\n')
                raise ValueError
            # thumbnail line
            lines[3] = lines[3].replace('thumbnail: ', '')
            if lines[3] != "Images/yoshi/yoshi_thumbnail.gif":
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect file in yoshi thumbnail" + '\n')
                raise OSError
            # image 1 line
            lines[4] = lines[4].replace('1: ', '')
            if lines[4] != 'Images/yoshi/4.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in yoshi image position 1" \
                              + '\n')
                raise OSError
            # image 2 line
            lines[5] = lines[5].replace('2: ', '')
            if lines[5] != 'Images/yoshi/3.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in yoshi image position 2" \
                              + '\n')
                raise OSError
            # image 3 line
            lines[6] = lines[6].replace('3: ', '')
            if lines[6] != 'Images/yoshi/2.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in yoshi image position 3" \
                              + '\n')
                raise OSError
            # image 4 line
            lines[7] = lines[7].replace('4: ', '')
            if lines[7] != 'Images/yoshi/blank.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in yoshi image position 4" \
                              + '\n')
                raise OSError
            
        # luigi filechecker
        elif filename == "luigi":
            # bring all lines in file to a list
            with open("./slider_puzzle_project_fall2021_assets/" \
                      "luigi.puz") as file:
                lines = file.readlines()
            # replace newline characters
            for i in range(len(lines)):
                lines[i] = lines[i].replace('\n', '')
            # check total file line length
            if len(lines) != luigi_fl_len:
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Value Error: Not enough metadata info" \
                              + '\n')
                raise ValueError
            # name line
            if lines[0] != "name: luigi":
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("incorrect name in yoshi metadata" \
                              + '\n')
                raise OSError
            # number line
            lines[1] = lines[1].replace('number: ', '')
            if int(lines[1]) != 9:
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Value Error: Incorrect Puzzle Size" \
                              + '\n')
                raise ValueError
            # size line
            lines[2] = lines[2].replace('size: ', '')
            if int(lines[2]) < 50 or int(lines[2]) > 110:
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Value Error: Incorrect Image Size" \
                              + '\n')
                raise ValueError
            # thumbnail line
            lines[3] = lines[3].replace('thumbnail: ', '')
            if lines[3] != "Images/luigi/luigi_thumbnail.gif":
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect file in luigi thumbnail" \
                              + '\n')
                raise OSError
            # image 1 line
            lines[4] = lines[4].replace('1: ', '')
            if lines[4] != 'Images/luigi/9.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in luigi image position 1" \
                              + '\n')
                raise OSError
            # image 2 line
            lines[5] = lines[5].replace('2: ', '')
            if lines[5] != 'Images/luigi/8.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in luigi image position 2" \
                              + '\n')
                raise OSError
            # image 3 line
            lines[6] = lines[6].replace('3: ', '')
            if lines[6] != 'Images/luigi/7.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in luigi image position 3" \
                              + '\n')
                raise OSError
            # image 4 line
            lines[7] = lines[7].replace('4: ', '')
            if lines[7] != 'Images/luigi/6.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in luigi image position 4" \
                              + '\n')
                raise OSError
            # image 5 line
            lines[8] = lines[8].replace('5: ', '')
            if lines[8] != 'Images/luigi/5.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in luigi image position 5" \
                              + '\n')
                raise OSError
            # image 6 line
            lines[9] = lines[9].replace('6: ', '')
            if lines[9] != 'Images/luigi/4.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in luigi image position 6" \
                              + '\n')
                raise OSError
            # image 7 line
            lines[10] = lines[10].replace('7: ', '')
            if lines[10] != 'Images/luigi/3.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in luigi image position 7" \
                              + '\n')
                raise OSError
            # image 8 line
            lines[11] = lines[11].replace('8: ', '')
            if lines[11] != 'Images/luigi/2.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in luigi image position 8" \
                              + '\n')
                raise OSError
            # image 9 line
            lines[12] = lines[12].replace('9: ', '')
            if lines[12] != 'Images/luigi/blank.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Incorrect image in luigi image position 9" \
                              + '\n')
                raise OSError

        # 16 x 16 filechecker
        elif filename == "mario" or filename == 'smiley' or \
           filename == 'fifteen':
            # bring all lines in file to a list
            with open("./slider_puzzle_project_fall2021_assets/" \
                      f"{filename}.puz") as file:
                lines = file.readlines()
            # replace all new line characters
            for i in range(len(lines)):
                lines[i] = lines[i].replace('\n', '')
            
            if len(lines) != fifteen_fl_len:
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Value Error: Not enough metadata info" \
                              + '\n')
                raise ValueError
            if lines[0] != f"name: {filename}":
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("incorrect name in yoshi metadata" \
                              + '\n')
                raise OSError
            # number line
            lines[1] = lines[1].replace('number: ', '')
            if int(lines[1]) != 16:
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Value Error: Incorrect Puzzle Size" \
                              + '\n')
                raise ValueError
            # size line
            lines[2] = lines[2].replace('size: ', '')
            if int(lines[2]) < 50 or int(lines[2]) > 110:
                errors.write(f"{time.localtime()}" + "\n")
                errors.write("Value Error: Incorrect Image Size" \
                              + '\n')
                raise ValueError
            # thumbnail line
            lines[3] = lines[3].replace('thumbnail: ', '')
            if lines[3] != f"Images/{filename}/{filename}_thumbnail.gif":
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect file in {filename} thumbnail" \
                              + '\n')
                raise OSError
            # image 1 line
            lines[4] = lines[4].replace('1: ', '')
            if lines[4] != f'Images/{filename}/16.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 1" + '\n')
                raise OSError
            # image 2 line
            lines[5] = lines[5].replace('2: ', '')
            if lines[5] != f'Images/{filename}/15.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 2" + '\n')
                raise OSError
            # image 3 line
            lines[6] = lines[6].replace('3: ', '')
            if lines[6] != f'Images/{filename}/14.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 3" + '\n')
                raise OSError
            # image 4 line
            lines[7] = lines[7].replace('4: ', '')
            if lines[7] != f'Images/{filename}/13.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 4" + '\n')
                raise OSError
            # image 5 line
            lines[8] = lines[8].replace('5: ', '')
            if lines[8] != f'Images/{filename}/12.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 5" + '\n')
                raise OSError
            # image 6 line
            lines[9] = lines[9].replace('6: ', '')
            if lines[9] != f'Images/{filename}/11.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 6" + '\n')
                raise OSError
            # image 7 line
            lines[10] = lines[10].replace('7: ', '')
            if lines[10] != f'Images/{filename}/10.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 7" + '\n')
                raise OSError
            # image 8 line
            lines[11] = lines[11].replace('8: ', '')
            if lines[11] != f'Images/{filename}/9.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 8" + '\n')
                raise OSError
            # image 9 line
            lines[12] = lines[12].replace('9: ', '')
            if lines[12] != f'Images/{filename}/8.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             "position 9" + '\n')
                raise OSError
            # image 10 line
            lines[13] = lines[13].replace('10: ', '')
            if lines[13] != f'Images/{filename}/7.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 10" + '\n')
                raise OSError
            # image 11 line
            lines[14] = lines[14].replace('11: ', '')
            if lines[14] != f'Images/{filename}/6.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 11" + '\n')
                raise OSError
            # image 12 line
            lines[15] = lines[15].replace('12: ', '')
            if lines[15] != f'Images/{filename}/5.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             "position 12" + '\n')
                raise OSError
            # image 13 line
            lines[16] = lines[16].replace('13: ', '')
            if lines[16] != f'Images/{filename}/4.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 13" + '\n')
                raise OSError
            # image 14 line
            lines[17] = lines[17].replace('14: ', '')
            if lines[17] != f'Images/{filename}/3.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 14" + '\n')
                raise OSError
            # image 15 line
            lines[18] = lines[18].replace('15: ', '')
            if lines[18] != f'Images/{filename}/2.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 15" + '\n')
                raise OSError
            # image 16 line
            lines[19] = lines[19].replace('16: ', '')
            if lines[19] != f'Images/{filename}/blank.gif':
                errors.write(f"{time.localtime()}" + "\n")
                errors.write(f"Incorrect image in {filename} image" \
                             " position 16" + '\n')
                raise OSError
