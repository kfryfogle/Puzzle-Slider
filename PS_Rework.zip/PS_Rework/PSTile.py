import turtle

'''
This class represents a Tile used within a puzzle slider game.
'''
class Tile():

    '''
    This is the constructor for the Tile class.
    '''
    def __init__(self):
        self.x = 0
        self.y = 0
        self.picture = None
        self.turtle = turtle.Turtle()
        self.turtle.penup()
        self.screen = turtle.Screen()
        self.visible = True

    '''
    Retrieves the current x coordinate of the current Tile object.
    '''
    def get_x(self):
        return self.x

    '''
    Retrieves the current y coordinate of the current Tile object.
    '''
    def get_y(self):
        return self.y

    '''
    Sets the current x and y coordinate of the current Tile object.
    '''
    def set_position(self, newx, newy):
        self.x = newx
        self.y = newy
        self.turtle.setposition(self.x, self.y)
        return

    '''
    Reveals the current Tile on the game table.
    '''
    def show_turtle(self):
        self.turtle.showturtle()
        self.visible = True

    '''
    Hides the current Tile object on the game table.
    '''
    def hide_turtle(self):
        self.turtle.hideturtle()
        self.visible = False

    '''
    Retrieves the current visiblity status of the current Tile object.
    will return a boolean True if the tile is visible, False if otherwise.
    '''
    def visibility(self):
        return self.visible

    '''
    Adds a new picture to the current Tile object.
    '''
    def add_picture(self, filepath):
        self.picture = filepath
        self.screen.addshape(filepath)
        self.turtle.shape(filepath)
    

    
        
