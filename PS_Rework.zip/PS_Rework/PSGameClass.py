from PSLeaderboard import Leaderboard
from PSOutline import outline
from PSPopup import Popup
from PSScoreboard import Scoreboard
from PSTile import Tile
from PSUtility import meta_reader
from PSUtility import tile_list
from PSUtility import random_locations
import time
import turtle

'''
This class represents the puzzle slider game object.
'''
class Game():

    '''
    Constructor for the Game class object.
    '''
    def __init__(self):
        # game screen for action events
        self.screen = turtle.Screen()
        # create a list of all tiles in the game
        self.tiles = tile_list()
        # create a scoreboard object
        self.score = Scoreboard()
        self.leader = Leaderboard()
        self.popup = Popup()
        # set white tile location after initialization
        self.whitex = None
        self.whitey = None
        # set variables for action button locations
        self.quitx = 255
        self.quity = -250
        self.loadx = 142.5
        self.loady = -249.5
        self.resetx = 50
        self.resety = -250
        # correct locations set based off what game is being played
        self.locations = []
        

    '''
    Presents the splash screen for the puzzle slider game.
    '''
    def splash(self):
        self.popup.splash_screen()

    '''
    Hides all turtles within the list of tiles.
    Function used specifically for changing game and reformatting tile images.
    '''
    def hide_tiles(self):
        for i in range(0, 16):
            self.tiles[i].hide_turtle()

    '''
    Setter method for the username of the current player.
    '''
    def username(self, username):
        self.leader.create_username(username)

    '''
    Setter method for the name of the current puzzle game.
    '''
    def game_name(self, game_name):
        self.leader.game_name(game_name)

    '''
    Setter method for the maximum moves possible in the current puzzle game.
    '''
    def set_cap(self, movecap):
        self.score.set_movecap(movecap)

    '''
    Checks if each tile is in its correct location within the max moves
    provided.
    Returns a boolean true if all tiles are in correct locations within range.
    '''
    def win_check(self):
        # check if the current game is ongoing
        if (self.score.ongoing_check()):
            win = False
            # check if moves are under or equal to move limit
            if (self.score.within_cap()):
                # if all tiles are in correct locations, win = true
                for i in range(0,len(self.locations)):
                    turt_x = self.tiles[i].get_x()
                    turt_y = self.tiles[i].get_y()
                    location_x = self.locations[i][0]
                    location_y = self.locations[i][1]
                    if (turt_x == location_x and turt_y == location_y):
                        win = True
                        continue
                    else:
                        win = False
                        break
                return win
        else:
            return False

    '''
    Setup function for creating the yoshi puzzle slider game.
    '''
    def yoshi_tiles(self):
        # define correct tile locations
        self.locations = [[-101, 26], [-199, 26], [-101, 124], [-199, 124]]
        # hide all tiles, clear board
        self.hide_tiles()
        # make list of tile locations for the yoshi game
        coords = random_locations("yoshi")
        # add pictures from turtle screen
        self.tiles[0].add_picture("./slider_puzzle_project_fall2021_assets" \
              f"/Images/yoshi/blank.gif")
        for i in range(1,4):
            self.tiles[i].add_picture("./slider_puzzle_project_fall" \
                                      "2021_assets/Images" \
                                      "/yoshi/{}.gif".format(i + 1))
        # move turtles to random locations
        for i in range(0, 4):
            # log white tile location
            if (i == 0):
                self.tiles[i].set_position(coords[i][0], coords[i][1])
                self.whitex = self.tiles[i].get_x()
                self.whitey = self.tiles[i].get_y()
            # else place other tiles
            self.tiles[i].set_position(coords[i][0], coords[i][1])
        # reveal each turtle
        for i in range(0,4):
            self.tiles[i].show_turtle()
        return

    '''
    Setup function for creating the luigi puzzle slider game.
    '''
    def luigi_tiles(self):
        # define correct tile locations
        '''
        self.locations = [[-3, -72], [-101, -72], [-199, -72], [-3, 26], \
                     [-101, 26], [-199, 26], [-3, 124], [-101, 124], \
                     [-199, 124]]
        '''
        self.locations = [[-51.5, -23], [-149.5, -23], [-247.5, -23], \
                          [-51.5, 75], [-149.5, 75], [-247.5, 75], \
                          [-51.5, 173], [-149.5, 173], [-247.5, 173]]
        # hide all tiles, clear board
        self.hide_tiles()
        # make list of tile locations for the yoshi game
        coords = random_locations("luigi")
        # add pictures from turtle screen
        self.tiles[0].add_picture("./slider_puzzle_project_fall2021_assets" \
              f"/Images/luigi/blank.gif")
        for i in range(1,9):
            self.tiles[i].add_picture("./slider_puzzle_project_fall" \
                                      "2021_assets/Images" \
                                      "/luigi/{}.gif".format(i + 1))
        # move turtles to random locations
        for i in range(0, 9):
            # log white tile location
            if (i == 0):
                self.tiles[i].set_position(coords[i][0], coords[i][1])
                self.whitex = self.tiles[i].get_x()
                self.whitey = self.tiles[i].get_y()
            # else place other tiles
            self.tiles[i].set_position(coords[i][0], coords[i][1])
        # reveal each turtle
        for i in range(0,9):
            self.tiles[i].show_turtle()
        return

    '''
    Setup function for creating the mario, smiley and fifteen puzzle
    slider game.
    '''
    def fifteen_tiles(self, name):
        # define correct tile locations
        self.locations = [[-3, -72], [-101, -72], [-199, -72], \
                          [-297, -72], [-3, 26], [-101, 26], \
                          [-199, 26], [-297, 26], [-3, 124], \
                          [-101, 124], [-199, 124], [-297, 124], \
                          [-3, 222], [-101, 222], [-199, 222], \
                          [-297, 222]]
        # hide all tiles, clear board
        self.hide_tiles()
        # make list of tile locations for the yoshi game
        coords = random_locations(name)
        # add pictures from turtle screen
        self.tiles[0].add_picture("./slider_puzzle_project_fall2021_assets" \
              f"/Images/" + name + "/blank.gif")
        for i in range(1, 16):
            self.tiles[i].add_picture("./slider_puzzle_project_fall" \
                                      "2021_assets/Images/" +
                                      name + "/{}.gif".format(i + 1))
        # move turtles to random locations
        for i in range(0, 16):
            # log white tile location
            if (i == 0):
                self.tiles[i].set_position(coords[i][0], coords[i][1])
                self.whitex = self.tiles[i].get_x()
                self.whitey = self.tiles[i].get_y()
            # else place other tiles
            self.tiles[i].set_position(coords[i][0], coords[i][1])
        # reveal each turtle
        for i in range(0,16):
            self.tiles[i].show_turtle()
        return


    '''
    Selector method that chooses tile format based off input string.
    '''
    def tile_select(self, name):
        # set declared game name if any legal names recognized
        if (name == "yoshi"):
            self.game_name(name)
            # check if leaderboard file exists
            self.leader.file_check()
            # update tile format and thumbnail
            self.score.hide_thumbnail()
            self.yoshi_tiles()
            self.score.thumbnail(name)
            self.score.update_scoreboard()
            self.leader.update_leaderboard()
        elif (name == "luigi"):
            self.game_name(name)
            # check if leaderboard file exists
            self.leader.file_check()
            # update tile format and thumbnail
            self.score.hide_thumbnail()
            self.luigi_tiles()
            self.score.thumbnail(name)
            self.score.update_scoreboard()
            self.leader.update_leaderboard()
        elif (name == "mario" or name == "smiley" or name == "fifteen"):
            self.game_name(name)
            # check if leaderboard file exists
            self.leader.file_check()
            # update tile format and thumbnail
            self.score.hide_thumbnail()
            self.fifteen_tiles(name)
            self.score.thumbnail(name)
            self.score.update_scoreboard()
            self.leader.update_leaderboard()

    '''
    Processes the location of each click in reference to tile locations.
    '''
    def game_click(self, x, y):
        leftx = self.whitex - 98
        rightx = self.whitex + 98
        downy = self.whitey - 98
        upy = self.whitey + 98
        # Check for visible popups
        if (self.popup.get_visible() == True):
            # hide popup on click
            self.popup.hide()
            return
        
        # Quit button
        if (x >= (self.quitx - 60) and x <= (self.quitx + 60) 
           and y >= (self.quity - 25) and y <= (self.quity + 25)):
            self.popup.quit_msg()
            time.sleep(4)
            turtle.bye()
            
        # Load button
        if (x >= (self.loadx - 37.5) and x <= (self.loadx + 37.5) 
           and y >= (self.loady - 37.5) and y <= (self.loady + 37.5)):
            new_puzzle = self.screen.textinput("5001 Puzzle Slide - Load", \
                                      "Which puzzle would you" \
                                      " like to switch" \
                                      " to?\nOptions:\nMario\n" \
                                      "Luigi\nYoshi\nSmiley\n" \
                                      "Fifteen")
            new_puzzle = new_puzzle.lower()
            # check metadata of the requested puzzle
            meta_reader(new_puzzle)
            # reset the current user score
            self.score.reset()
            # set up new tiles
            self.tile_select(new_puzzle)
            
        # Reset button
        if (x >= (self.resetx - 40) and x <= (self.resetx + 40) 
           and y >= (self.resety - 40) and y <= (self.resety + 40)):
            j = 0
            for i in self.locations:
                self.tiles[j].set_position(i[0], i[1])
                j += 1
                #record white tile position
                self.whitex = self.tiles[0].get_x()
                self.whitey = self.tiles[0].get_y()
            # freeze the scoreboard
            self.score.freeze()
            
        # check if clicks are around the white tile's location
        # only vertically or horizontally, not diagonally
        # right side of white tile, same y but using rightx
        if (y <= (self.whitey + 48) and x >= (rightx - 48)
            and x <= (rightx + 48) and y >= (self.whitey - 48)):
            # check if any tiles are in this range
            for i in range(0, 16):
                visible = self.tiles[i].visibility()
                tilex = self.tiles[i].get_x()
                tiley = self.tiles[i].get_y()
                # if tile in range of click, swap tile
                if (tiley <= (self.whitey + 48) and tilex >= (rightx - 48)
                    and tilex <= (rightx + 48) and tiley >= (self.whitey - 48)
                    and visible == True):
                    self.tiles[0].set_position(tilex, tiley)
                    self.tiles[i].set_position(self.whitex, self.whitey)
                    # log new location of white tile
                    self.whitex = tilex
                    self.whitey = tiley
                    # if the game is ongoing
                    if (self.score.ongoing_check()):
                        # increment score and update board
                        self.score.increment()
                        self.score.update_scoreboard()
            
        # left side, same y but using leftx
        if (y <= (self.whitey + 48) and x >= (leftx - 48)
            and x <= (leftx + 48) and y >= (self.whitey - 48)):
            # check if any tiles are in this range
            for i in range(0, 16):
                visible = self.tiles[i].visibility()
                tilex = self.tiles[i].get_x()
                tiley = self.tiles[i].get_y()
                # if tile in range of click, swap tile
                if (tiley <= (self.whitey + 48) and tilex >= (leftx - 48)
                    and tilex <= (leftx + 48) and tiley >= (self.whitey - 48)
                    and visible == True):
                    self.tiles[0].set_position(tilex, tiley)
                    self.tiles[i].set_position(self.whitex, self.whitey)
                    # log new location of white tile
                    self.whitex = tilex
                    self.whitey = tiley
                    # if the game is ongoing
                    if (self.score.ongoing_check()):
                        # increment score and update board
                        self.score.increment()
                        self.score.update_scoreboard()
        
        # on top of white tile, same x but using upy
        if (y <= (upy + 48) and x >= (self.whitex - 48)
            and x <= (self.whitex + 48) and y >= (upy - 48)):
            # check if any tiles are in this range
            for i in range(0, 16):
                visible = self.tiles[i].visibility()
                tilex = self.tiles[i].get_x()
                tiley = self.tiles[i].get_y()
                # if tile in range of click, swap tile
                if (tiley <= (upy + 48) and tilex >= (self.whitex - 48)
                    and tilex <= (self.whitex + 48) and tiley >= (upy - 48)
                    and visible == True):
                    self.tiles[0].set_position(tilex, tiley)
                    self.tiles[i].set_position(self.whitex, self.whitey)
                    # log new location of white tile
                    self.whitex = tilex
                    self.whitey = tiley
                    # if the game is ongoing
                    if (self.score.ongoing_check()):
                        # increment score and update board
                        self.score.increment()
                        self.score.update_scoreboard()
                    

        # below white tile, same x but using upy
        if (y <= (downy + 48) and x >= (self.whitex - 48)
            and x <= (self.whitex + 48) and y >= (downy - 48)):
            # check if any tiles are in this range
            for i in range(0, 16):
                visible = self.tiles[i].visibility()
                tilex = self.tiles[i].get_x()
                tiley = self.tiles[i].get_y()
                # if tile in range of click, swap tile
                if (tiley <= (downy + 48) and tilex >= (self.whitex - 48)
                    and tilex <= (self.whitex + 48) and tiley >= (downy - 48)
                    and visible == True):
                    self.tiles[0].set_position(tilex, tiley)
                    self.tiles[i].set_position(self.whitex, self.whitey)
                    # log new location of white tile
                    self.whitex = tilex
                    self.whitey = tiley
                    # if the game is ongoing
                    if (self.score.ongoing_check()):
                        # increment score and update board
                        self.score.increment()
                        self.score.update_scoreboard()

        # check if the puzzle is completed, game won
        if (self.win_check() == True):
            # mark game as complete and check scores on leaderboard
            self.score.complete()
            self.popup.win_msg()
            self.leader.check_competition(self.score.get_count(),
                                          self.score.get_movecap())
            self.leader.update_leaderboard()

        # check if the game has been lost
        if (self.win_check() != True and self.score.within_cap() != True):
            self.popup.lose_msg()

        
    
    def game_start():
        ts = turtle.Screen()
        game = Game()
        game.splash()
        game.hide_tiles()
        username = ts.textinput("CS 5001 Puzzle Slide", "Your name:")
        moves = int(ts.numinput("5001 Puzzle Slide - Moves", "Enter the "\
                         "number of moves (chances) you want:", \
                        minval=5, maxval=200))
        outline()
        game.tile_select("luigi")
        game.username(username)
        game.set_cap(moves)
        ts.onclick(game.game_click)
    
        
        
