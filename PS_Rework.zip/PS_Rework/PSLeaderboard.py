import os.path
import turtle

'''
This class represents the leaderboard object of the a puzzle slider instance.
'''
class Leaderboard():

    '''
    This is the constructor for the Leaderboard object.
    '''
    def __init__(self):
        self.turtle = turtle.Turtle()
        self.turtle.hideturtle()
        # username and game type will be updated upon game start
        self.username = None
        self.game = None

    '''
    Setter method for the username of the current player.
    '''
    def create_username(self, username):
        self.username = username

    '''
    Setter method for the name of the current puzzle game.
    '''
    def game_name(self, game_name):
        self.game = game_name

    '''
    Method used to check if a leaderboard log file exists.
    Creates a new leaderboard log file if not found.
    '''
    def file_check(self):
        # if leaderboard directory missing, write blank version
        if os.path.exists('./leaderboard/'):
            pass
        else:
            os.makedirs('./leaderboard/')
        # if file missing, write blank version
        if os.path.exists(f'./leaderboard/{self.game}_leaders.txt'):
            return
        else:
            open(f'./leaderboard/{self.game}_leaders.txt', mode='w').close()
            

    '''
    Function used to update the list of leaders if current score
    is high enough.
    '''
    def update_leaderboard(self):
        style = ('Calibri', 24, 'bold')
        with open(f"./leaderboard/{self.game}_leaders.txt", mode='r') as \
             leaderboard:
            board = leaderboard.readlines()
            for i in range(len(board)):
                board[i] = board[i].replace("\n", "")
                board[i] = board[i].split(':')
        # clear the leaderboard space
        self.turtle.pencolor("#350A0A")
        self.turtle.speed(0)
        self.turtle.penup()
        self.turtle.hideturtle()
        self.turtle.setpos(110, 200)
        self.turtle.fillcolor("beige")
        self.turtle.begin_fill()
        self.turtle.setheading(270)
        self.turtle.forward(300)
        self.turtle.left(90)
        self.turtle.forward(150)
        self.turtle.left(90)
        self.turtle.forward(300)
        self.turtle.left(90)
        self.turtle.forward(150)
        self.turtle.left(90)
        self.turtle.end_fill()
        # reset position to top of leaderboard
        self.turtle.setpos(110, 160)
        # write out list of leaders and their scores
        for i in range(len(board)):
            score = f"{board[i][1]}: {board[i][0]}"
            self.turtle.write(score, font=style, align='left')
            self.turtle.forward(60)

    '''
    Function used to check the current score of the current player upon
    finishing a puzzle.
    '''
    def check_competition(self, score, movecap):
        board = []
        current_score = [self.username, str(score), str(movecap)]
        # adds all logged top scores to board list
        with open(f"./leaderboard/{self.game}_leaders.txt".format(self.game),
                  mode='r') as leaderboard:
            board = leaderboard.readlines()
            
        # remove new line characters
        for i in range(len(board)):
            board[i] = board[i].replace("\n", "")
            
        # if the leaderboard is empty add the current winner to the board
        if len(board) == 0:
            with open(f"./leaderboard/{self.game}_leaders.txt", mode='w') as \
                 empty_board:
                current_score = ':'.join(current_score)
                empty_board.write(current_score)
                empty_board.close()
            return
        
        elif len(board) < 5:
            for i in range(len(board)):
                board[i] = board[i].split(":")
            # find index where current score is less than a leader
            for i in range(len(board)):
                # skip if score is greater
                if int(current_score[1]) > int(board[i][1]):
                    continue
            # append index, break loop if score <= current line
                elif int(current_score[1]) <= int(board[i][1]):
                    index_holder = i
                    break
            # failsafe if current score > all available
            if int(current_score[1]) > int(board[-1][1]):
                board.append(current_score)
            elif index_holder >= 0:
                board.insert(index_holder, current_score)
            else:
                pass
            # need to write new scores back to file
            with open(f"./leaderboard/{self.game}_leaders.txt".format(self.game),
                      mode='w') as new_leads:
                # del new line characters from last document
                for each in board:
                    each = ':'.join(each)
                # reapply new line character for all but last index
                for i in range(len(board)):
                    if board[i] == board[-1]:
                        board[i] = ':'.join(board[i])
                        pass
                    else:
                        board[i][2] = board[i][2] + '\n'
                        board[i] = ':'.join(board[i])
                for each in board:
                    new_leads.write(each)
                new_leads.close()
            return
                
        elif len(board) == 5:
            for i in range(len(board)):
                board[i] = board[i].split(":")
            # find index where current score is less than leader
            for i in range(len(board)):
                # skip if score is greater
                if int(current_score[1]) > int(board[i][1]):
                    continue
                # append index, break loop if score <= current line
                elif int(current_score[1]) <= int(board[i][1]):
                    index_holder = i
                    break
            # failsafe if current score > all available
            if int(current_score[1]) > int(board[-1][1]):
                board.append(current_score)
            elif index_holder >= 0:
                board.insert(index_holder, current_score)
            else:
                pass
            # del last value before reformatting
            board.pop()
            # need to write new scores back to file
            with open(f"./leaderboard/{self.game}" +
                      "_leaders.txt".format(self.game), mode='w') as new_leads:
                # del new line characters from last document
                for each in board:
                    each = ':'.join(each)
                # reapply new line character for all but last index
                for i in range(len(board)):
                    if board[i] == board[-1]:
                        board[i] = ':'.join(board[i])
                        pass
                    else:
                        board[i][2] = board[i][2] + '\n'
                        board[i] = ':'.join(board[i])
                for each in board:
                    new_leads.write(each)
                new_leads.close()
            return
                
