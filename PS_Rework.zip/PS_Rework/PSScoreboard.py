import turtle

'''
Scoreboard Class Object
'''
class Scoreboard:

    '''
    Constructor for the scoreboard class object
    '''
    def __init__(self):
        self.count = 0
        # movecap isnt set until game initialization
        self.movecap = None
        self.status = "ongoing"
        # scoreboardturtle
        self.turtle = turtle.Turtle()
        self.turtle.hideturtle()
        # thumbnail turtle
        self.thumb = turtle.Turtle()
        self.thumb.hideturtle()
        self.screen = turtle.Screen()

    '''
    Increments the current game score by 1 point if the game is ongoing
    '''
    def increment(self):
        if (self.status == "ongoing"):
            self.count = self.count + 1
        return

    '''
    Getter method for the current player's move count
    '''
    def get_count(self):
        return self.count
    '''
    Setter method for the movecap of the current game being played
    '''
    def set_movecap(self, cap):
        self.movecap = cap

    '''
    Getter method for the movecap of the current game being played
    '''
    def get_movecap(self):
        return self.movecap

    '''
    Getter method returns a boolean true if the number of current moves is
    under the maximum amount set to win the game
    '''
    def within_cap(self):
        if (self.count <= self.movecap):
            return True
        return False
    
    '''
    Setter method used to freeze the current games scoreboard
    '''
    def freeze(self):
        self.status = "frozen"

    '''
    Setter method used to return game state to ongoing
    '''
    def unfreeze(self):
        self.status = "ongoing"

    '''
    Setter method used to determine that the game has been completed
    '''
    def complete(self):
        self.status = "finished"

    '''
    Setter method brings the Scoreboard object to factory settings upon initialization
    '''
    def reset(self):
        self.status = "ongoing"
        self.count = 0
        self.update_scoreboard()

    '''
    Getter method used to determine the activity status of the current game
    '''
    def status_check(self):
        return self.status

    '''
    Method used to determine whether a game is ongoing or not
    returns a boolean true if the scoreboard is ongoing, false if otherwise
    '''
    def ongoing_check(self):
        if (self.status == "ongoing"):
            return True
        return False

    '''
    Function used to update the thumbnail of the current game board
    '''
    def thumbnail(self, image: str):
        self.thumb.penup()
        self.thumb.hideturtle()
        self.thumb.setposition(290, 260)
        pic = "./slider_puzzle_project_fall2021_assets/Images/" \
              f"{image}/{image}_thumbnail.gif"
        self.screen.addshape(pic)
        self.thumb.shape(pic)
        self.thumb.showturtle()

    '''
    Function used to hide the current thumbnail image
    '''
    def hide_thumbnail(self):
        self.thumb.hideturtle()

    '''
    Function used to update the turtle on the active scoreboard
    '''
    def update_scoreboard(self):
        turtle.speed(0)
        turtle.hideturtle()
        turtle.penup()
        turtle.setpos(-188, -267)
        turtle.fillcolor('beige')
        turtle.begin_fill()
        turtle.forward(100)
        turtle.left(90)
        turtle.forward(50)
        turtle.left(90)
        turtle.forward(103)
        turtle.left(90)
        turtle.forward(50)
        turtle.left(90)
        turtle.forward(3)
        turtle.end_fill()
        turtle.pencolor("#350A0A")
        style = ('Calibri', 26, 'bold')
        turtle.write(f"{self.count}", font=style, align='left')
        

    
        
