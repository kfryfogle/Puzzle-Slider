import turtle
import time

'''
This object represents a Popup item within the GameClass object.
'''
class Popup:

    '''
    This is the constructor for the Popup class object
    '''
    def __init__(self):
        self.screen = turtle.Screen()
        self.turtle = turtle.Turtle()
        self.splash_turt = turtle.Turtle()
        self.turtle.hideturtle()
        self.splash_turt.hideturtle()
        self.visible = False
        self.quit = "./slider_puzzle_project_fall2021_assets/" \
                                "Resources/quitmsg.gif"
        self.win = "./slider_puzzle_project_fall2021_assets/" \
                            "Resources/winner.gif"
        self.lose = "./slider_puzzle_project_fall2021_assets/" \
                            "Resources/Lose.gif"
        self.splash = "./slider_puzzle_project_fall2021_assets/Resources/" \
                      "splash_screen.gif"
        self.screen.addshape(self.quit)
        self.screen.addshape(self.win)
        self.screen.addshape(self.lose)
        self.screen.addshape(self.splash)

    '''
    Retrieves the current visibility status of the Popup object.
    Returns a boolean true if a popup is current visible, false if otherwise.
    '''
    def get_visible(self):
        return self.visible

    '''
    Shows the splash screen popup upon loading into the game.
    '''
    def splash_screen(self):
        self.splash_turt.shape(self.splash)
        self.splash_turt.showturtle()
        time.sleep(4)
        self.splash_turt.hideturtle()

    '''
    Reveals a quit message popup upon use.
    '''
    def quit_msg(self):
        self.turtle.shape(self.quit)
        self.turtle.showturtle()
        self.visible = True

    '''
    Reveals a win message popup upon use.
    '''
    def win_msg(self):
        self.turtle.shape(self.win)
        self.turtle.showturtle()
        self.visible = True

    '''
    Reveals a lose message popup upon use.
    '''
    def lose_msg(self):
        self.turtle.shape(self.lose)
        self.turtle.showturtle()
        self.visible = True

    '''
    Hides the current visible Popup
    '''
    def hide(self):
        self.turtle.hideturtle()
        self.visible = False
    
