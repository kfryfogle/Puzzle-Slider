'''
Kyle Fryfogle

Summer 2022
Puzzle Slider Rework
'''

from PS_Rework.PSGameClass import Game

'''
Function writes the outline of the game board as well as creates a game instance
'''
def game_start():
    Game.game_start()

if __name__ == "__main__":
    game_start()
