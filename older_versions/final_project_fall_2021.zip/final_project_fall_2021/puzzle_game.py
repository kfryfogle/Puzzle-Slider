'''
CS 5001
Fall 2021
Final Project

Kyle Fryfogle
'''
import turtle
import PositionService
import os.path
import time
from turtle_template import outline
from turtle_template import top_window
from Tile_testing import meta_reader
from Tile_testing import visibility_check
from Tile_testing import random_locations
from Tile_testing import game_picker
from Tile_testing import yoshi_game
from Tile_testing import luigi_game
from Tile_testing import mario_game
from Tile_testing import smiley_game
from Tile_testing import fifteen_game

def game_start():
    ts = turtle.Screen()
    splash = turtle.Turtle()
    splash.hideturtle()
    ts.addshape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "splash_screen.gif")
    username = ts.textinput("CS 5001 Puzzle Slide", "Your name:")
    moves = int(ts.numinput("5001 Puzzle Slide - Moves", "Enter the "\
                         "number of moves (chances) you want:", \
                        minval=5, maxval=200))
    score = 0
    splash.shape("../final_project_fall_2021/" \
                "slider_puzzle_project_fall2021_assets/Resources/" \
                "splash_screen.gif")
    splash.showturtle()
    time.sleep(8)
    splash.hideturtle()
    outline()
    with open("scorekeeper.txt", mode='w') as scoreboard:
        scoreboard.write(f"{username}:{score}:{moves}")
    mario_game(username, moves)
    
def main():
    game_start()
if __name__ == "__main__":
    main()
